package br.rj.senac.biblisoft.model.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;



import br.rj.senac.biblisoft.model.Editora;
import br.rj.senac.biblisoft.model.conexao.Conexao;
import br.rj.senac.biblisoft.model.table.AutorTableModel;
import br.rj.senac.biblisoft.model.table.EditoraTableModel;
import br.rj.senac.biblisoft.view.EditoraView;
import br.rj.senac.biblisoft.view.EntityModelView;
import br.rj.senac.biblisoft.view.LivroView;


public class EditoraDAO {
	Connection conn = Conexao.getConexao();

	public void incluir(Editora editora) {
		int resultado = 0;
		try {

			String query = "INSERT INTO EDITORA(NOME) VALUES (?)";
			PreparedStatement ps = conn.prepareStatement(query);
			ps.setString(1, editora.getNome());

			ps.executeUpdate();

			conn.commit();
			// conn.close();

		} catch (SQLException e) {
			System.out
					.println("houve algum erro ao tentar inserir dados na tabela de editoras");

		}


	}

	public void delete(Editora editora) {
		try {

			String query = "DELETE FROM EDITORA WHERE EDITORA_ID =(?)";

			PreparedStatement ps = conn.prepareStatement(query);

			ps.setInt(1, editora.getId());
			ps.executeUpdate();

			conn.commit();
			// conn.close();

		} catch (SQLException e) {
			System.out
					.println("houve algum problema ao tentar remover dados da tabela de editoras");
		}

	}

	public void update(Editora editora) {
		try {
			String query = "UPDATE EDITORA SET NOME = (?) WHERE EDITORA_ID = (?)";
			PreparedStatement ps = conn.prepareStatement(query);
			ps.setString(1, editora.getNome());
			ps.setInt(2, editora.getId());
			ps.executeUpdate();
			conn.commit();
			conn.close();
		} catch (SQLException e) {
			System.out
					.println("houve algum problema ao tentar atualizar o cadastro de um editora");
		}

	}

	public void select(Editora editora, EditoraView tela) {
		ResultSet rs = null;
		// System.out.println(editora.getId());
		try {

			String query = "SELECT * FROM EDITORA WHERE EDITORA_ID = ?";
			PreparedStatement ps = conn.prepareStatement(query);
			ps.setInt(1, editora.getId());
			rs = ps.executeQuery();
			while (rs.next()) {

				String nome = (rs.getString("NOME"));

				tela.getNomeField().setText(nome);

			}
			tela.getIdField().setText("" + editora.getId());
		} catch (SQLException e) {
			System.out
					.println("houve algum problema ao tentar selecionar os dados de um editora");
		}

	}

	public String selectId(Editora editora) {
		
		ResultSet rs = null;
		String id = null;
		// System.out.println(editora.getId());
		try {

			String query = "SELECT * FROM EDITORA WHERE NOME = ?";
			PreparedStatement ps = conn.prepareStatement(query);
			ps.setString(1, editora.getNome());
			rs = ps.executeQuery();
			while (rs.next()) {

				id = (rs.getString("EDITORA_ID"));
				// System.out.println(id);

				// conn.close();

			}

		} catch (SQLException e) {
			System.out
					.println("houve algum problema ao tentar selecionar o ID de um editora");
		}
		return id;
		
	}
		public String selectNome(int id) {
			ResultSet rs = null;
			String nome = null;
			// System.out.println(editora.getId());
			try {

				String query = "SELECT * FROM EDITORA WHERE EDITORA_ID = ?";
				PreparedStatement ps = conn.prepareStatement(query);
				ps.setInt(1, id);
				rs = ps.executeQuery();
				while (rs.next()) {

					nome = (rs.getString("NOME"));
					// System.out.println(id);

					// conn.close();

				}

			} catch (SQLException e) {
				System.out
						.println("houve algum problema ao tentar selecionar o nome de um editora");
			}
			return nome;

	}

	public String selectNome(Editora editora) {
		ResultSet rs = null;
		String nome = null;
		// System.out.println(editora.getId());
		try {

			String query = "SELECT * FROM EDITORA WHERE EDITORA_ID = ?";
			PreparedStatement ps = conn.prepareStatement(query);
			ps.setInt(1, editora.getId());
			rs = ps.executeQuery();
			while (rs.next()) {

				nome = (rs.getString("NOME"));
				// System.out.println(id);

				// conn.close();

			}

		} catch (SQLException e) {
			System.out
					.println("houve algum problema ao tentar selecionar o ID de um editora");
		}
		return nome;

	}

	public void listar(EntityModelView tela) {
		EditoraTableModel.dados.clear();

		try {
			String query = "SELECT EDITORA_ID,NOME FROM EDITORA ORDER BY NOME";
			PreparedStatement sql = conn.prepareStatement(query);
			ResultSet rs = sql.executeQuery();
			conn.commit();

			while (rs.next()) {
				Integer id = rs.getInt("EDITORA_ID");
				String nome = rs.getString("NOME");

				EditoraTableModel.dados.add(new String[] { "" + id + "","" + nome + "" });
				

			}

		} catch (SQLException e) {
			System.out
					.println("Houve algum problema ao exibir os dados na tela");

		}

	}
	
	public void listarChoice(EntityModelView tela) {
		AutorTableModel.dados.clear();
		LivroView.getEditora().removeAll();

		try {
			String query = "SELECT EDITORA_ID,NOME FROM EDITORA ORDER BY NOME";
			PreparedStatement sql = conn.prepareStatement(query);
			ResultSet rs = sql.executeQuery();
			conn.commit();
			LivroView.getEditora().add("");
			while (rs.next()) {
				Integer id = rs.getInt("EDITORA_ID");
				String nome = rs.getString("NOME");
				LivroView.getEditora().add(nome);
				AutorTableModel.dados.add(new String[] { "" + id + "",
						"" + nome + "" });

			}

		} catch (SQLException e) {
			System.out
					.println("Houve algum problema ao exibir os dados na tela");

		}

	}

}
