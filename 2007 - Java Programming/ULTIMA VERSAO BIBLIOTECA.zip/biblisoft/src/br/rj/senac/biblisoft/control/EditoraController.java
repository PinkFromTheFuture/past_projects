package br.rj.senac.biblisoft.control;

import java.util.Collection;

import br.rj.senac.biblisoft.model.Editora;
import br.rj.senac.biblisoft.model.EntityModel;
import br.rj.senac.biblisoft.model.conexao.MyConnection;
import br.rj.senac.biblisoft.model.DAO.EditoraDAO;
import br.rj.senac.biblisoft.exception.BusinessException;
import br.rj.senac.biblisoft.exception.DatabaseException;

public class EditoraController extends BibliosoftController {

	private EditoraDAO editoraDAO = new EditoraDAO();
	
	public EditoraController() {
		
	}
	
	public void inserirEditora(Editora editora) throws BusinessException, DatabaseException {
		try {
			
			MyConnection.beginTransaction();
			
			criticarEditora(editora);
			
			editoraDAO.incluir(editora);
			MyConnection.commit();
			
		} catch (Exception e) {

			super.doRollback(e);
		}
	}
	
	public void excluirEditora(Editora editora) throws BusinessException, DatabaseException {
		try {
			
			MyConnection.beginTransaction();
			editoraDAO.delete(editora);
			MyConnection.commit();
			
		} catch (Exception e) {
			
			super.doRollback(e);
		}
	}
	
	public void alterarEditora(Editora editora) throws BusinessException, DatabaseException {
		try {
			
			MyConnection.beginTransaction();
			editoraDAO.update(editora);
			MyConnection.commit();
			
		} catch (Exception e) {
			
			super.doRollback(e);
		}
	}
	
	public Collection<? extends EntityModel> pesquisarEditora(Editora editora) throws BusinessException, DatabaseException {
		try {
			
			return editoraDAO.select(editora);
			
		} catch (Exception e) {
			
			super.doRollback(e);
			
			return null;
		}
	}
	
	private void criticarEditora(Editora editora) throws BusinessException{
		
		if(editora.getNome()==null){
			
			throw new BusinessException("Todos os campos devem ser preenchidos!");
			
		}
	}
}
