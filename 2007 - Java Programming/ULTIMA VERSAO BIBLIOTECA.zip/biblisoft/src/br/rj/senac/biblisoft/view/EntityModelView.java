package br.rj.senac.biblisoft.view;

import javax.swing.JFrame;

public abstract class EntityModelView extends JFrame {

}
