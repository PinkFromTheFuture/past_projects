package br.rj.senac.biblisoft.model;

public abstract class EntityModel {

}
