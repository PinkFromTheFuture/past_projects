package br.rj.senac.biblisoft.control;

import java.util.Collection;

import br.rj.senac.biblisoft.model.Curso;
import br.rj.senac.biblisoft.model.EntityModel;
import br.rj.senac.biblisoft.model.conexao.MyConnection;
import br.rj.senac.biblisoft.model.DAO.CursoDAO;

import br.rj.senac.biblisoft.exception.BusinessException;
import br.rj.senac.biblisoft.exception.DatabaseException;

public class CursoController extends BibliosoftController {
private CursoDAO cursoDAO = new CursoDAO();
	
	public CursoController() {
		
	}
	
	public void inserirCurso(Curso curso) throws BusinessException, DatabaseException {
		try {
			
			MyConnection.beginTransaction();
			
			criticarCurso(curso);
			
			cursoDAO.incluir(curso);
			MyConnection.commit();
			
		} catch (Exception e) {

			super.doRollback(e);
		}
	}
	
	public void excluirCurso(Curso curso) throws BusinessException, DatabaseException {
		try {
			
			MyConnection.beginTransaction();
			cursoDAO.delete(curso);
			MyConnection.commit();
			
		} catch (Exception e) {
			
			super.doRollback(e);
		}
	}
	
	public void alterarCurso(Curso curso) throws BusinessException, DatabaseException {
		try {
			
			MyConnection.beginTransaction();
			cursoDAO.update(curso);
			MyConnection.commit();
			
		} catch (Exception e) {
			
			super.doRollback(e);
		}
	}
	
	public Collection<? extends EntityModel> pesquisarCurso(Curso curso) throws BusinessException, DatabaseException {
		try {
			
			return cursoDAO.select(curso);
			
		} catch (Exception e) {
			
			super.doRollback(e);
			
			return null;
		}
	}
	
	private void criticarCurso(Curso curso) throws BusinessException{
		
		if(curso.getNome()== null){
			
			throw new BusinessException("Todos os campos devem ser preenchidos!");
			
		}
	}
}
