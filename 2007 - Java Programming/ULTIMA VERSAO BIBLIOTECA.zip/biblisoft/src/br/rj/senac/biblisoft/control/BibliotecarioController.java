package br.rj.senac.biblisoft.control;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Collection;

import br.rj.senac.biblisoft.model.Autor;
import br.rj.senac.biblisoft.model.Bibliotecario;
import br.rj.senac.biblisoft.model.EntityModel;
import br.rj.senac.biblisoft.model.conexao.MyConnection;
import br.rj.senac.biblisoft.model.table.AutorTableModel;
import br.rj.senac.biblisoft.model.table.BibliotecarioTableModel;
import br.rj.senac.biblisoft.model.DAO.BibliotecarioDAO;
import br.rj.senac.biblisoft.view.BibliotecarioView;
import br.rj.senac.biblisoft.view.EntityModelView;

import br.rj.senac.biblisoft.exception.BusinessException;
import br.rj.senac.biblisoft.exception.DAOException;
import br.rj.senac.biblisoft.exception.DatabaseException;

public class BibliotecarioController extends BibliosoftController {

	private BibliotecarioDAO bibliotecarioDAO = new BibliotecarioDAO();
	
	public BibliotecarioController() {
		
	}
	
	public void inserirBibliotecario(Bibliotecario bibliotecario) throws BusinessException, DatabaseException {
		try {
			
			MyConnection.beginTransaction();
			
			criticarBibliotecario(bibliotecario);
			
			bibliotecarioDAO.incluir(bibliotecario);
			MyConnection.commit();
			
		} catch (Exception e) {

			super.doRollback(e);
		}
	}
	
	public void excluirBibliotecario(Bibliotecario bibliotecario) throws BusinessException, DatabaseException {
		try {
			
			MyConnection.beginTransaction();
			bibliotecarioDAO.delete(bibliotecario);
			MyConnection.commit();
			
		} catch (Exception e) {
			
			super.doRollback(e);
		}
	}
	
	public void alterarBibliotecario(Bibliotecario bibliotecario) throws BusinessException, DatabaseException {
		try {
			
			MyConnection.beginTransaction();
			bibliotecarioDAO.update(bibliotecario);
			MyConnection.commit();
			
		} catch (Exception e) {
			
			super.doRollback(e);
		}
	}
	
	public void pesquisarBibliotecario(Bibliotecario bibliotecario, BibliotecarioView tela) throws BusinessException, DatabaseException {
		try {
			
			bibliotecarioDAO.select(bibliotecario, tela);
			
		} catch (Exception e) {
			
			super.doRollback(e);
			
			
		}
	}
	
	public void listar(EntityModelView tela) throws BusinessException, DatabaseException {
		BibliotecarioTableModel.dados.clear();

		try {
			bibliotecarioDAO.listar(tela);



		} catch (Exception e) {
			super.doRollback(e);

		}

	}
	
	
	
	public String getId(Autor autor) throws DAOException{
		
		int id = -99999;
		
		try {

			String query = "SELECT * FROM AUTOR WHERE NOME = ?";
			PreparedStatement ps = conn.prepareStatement(query);
			ps.setString(1, autor.getNome());
			rs = ps.executeQuery();
			while (rs.next()) {

				id = (rs.getString("AUTOR_ID"));
				// System.out.println(id);

				// conn.close();

			}

		} catch (Exception e) {
			throw new DAOException(e);
		}
		return id;

	}
	
	
	
	private void criticarBibliotecario (Bibliotecario bibliotecario) throws BusinessException{
		
		if (bibliotecario.getNome() == null  ){
			
			throw new BusinessException("Todos os campos devem ser preenchidos!");
			
		}
	}
}
