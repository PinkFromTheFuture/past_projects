package br.rj.senac.bibliosoft.model.dao;

import java.util.List;

import br.rj.senac.bibliosoft.exception.DAOException;
import br.rj.senac.bibliosoft.model.Usuario;

public interface IUsuarioDAO extends IBibliosoftDAO {
	public Usuario pesquisarById(Long usuarioId) throws DAOException;
	public List<Usuario> pesquisar(Usuario usuario) throws DAOException;
}
