package br.rj.senac.bibliosoft.model.dao;

import java.util.Collection;

import br.rj.senac.bibliosoft.exception.DAOException;
import br.rj.senac.bibliosoft.model.Curso;
import br.rj.senac.bibliosoft.model.Usuario;
import br.rj.senac.bibliosoft.model.UsuarioCurso;

public interface IUsuarioCursoDAO {

	public void inserir(UsuarioCurso uc) throws DAOException;
	public void excluir(UsuarioCurso uc) throws DAOException;
	public Collection<UsuarioCurso> pesquisarByCurso(Curso c) throws DAOException;
	public Collection<UsuarioCurso> pesquisarByUsuario(Usuario u) throws DAOException;
}
