package br.rj.senac.bibliosoft.model.conexao;

import java.sql.Connection;
import java.sql.DriverManager;

/**
 * Isola e encapsula o tratamento de transa��o e obten��o da conex�o do banco 
 * de dados via JDBC em um �nico ponto.
 */
public class MyConnection {

	private static Connection conn;
	
	/**
	 * Obt�m uma conex�o JDBC.
	 */
	public static Connection getConnection() {	
		try {
			
			if (conn == null || conn.isClosed()) {
				Class.forName("com.mysql.jdbc.Driver");
				
				conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/biblioteca?user=root&password=123456");
				
				conn.setAutoCommit(Boolean.FALSE);
			}
			
			return conn;
			
		} catch (Exception e) {
			
			System.out.println(e.getStackTrace().toString() );
			
			return null;
		}
	}
	
	/**
	 * Prepara uma transa��o para ser iniciada.
	 */
	public static void beginTransaction() {
		MyConnection.getConnection();
	}
	
	/**
	 * Encapsula o m�todo commit da interface Connection.
	 */
	public static void commit() {
		try {
			
			if (MyConnection.getConnection() != null) {
				conn.commit();	
			}
			
		} catch (Exception e) {
			System.out.println(e.getStackTrace().toString() );
		}
	}
	
	/**
	 * Encapsula o m�todo rollback da interface Connection.
	 */
	public static void rollback() {
		try {
			
			if (MyConnection.getConnection() != null) {
				conn.rollback();	
			}
			
		} catch (Exception e) {
			System.out.println(e.getStackTrace().toString() );
		}
	}
}
