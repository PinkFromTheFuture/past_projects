package br.rj.senac.bibliosoft.model.dao;

import java.util.Collection;

import br.rj.senac.bibliosoft.exception.DAOException;
import br.rj.senac.bibliosoft.model.Autor;
import br.rj.senac.bibliosoft.model.Livro;
import br.rj.senac.bibliosoft.model.LivroAutor;

public interface ILivroAutorDAO {
	
	public void inserir(LivroAutor la) throws DAOException;
	public void excluir(LivroAutor la) throws DAOException;
	public Collection<LivroAutor> pesquisarByLivro(Livro l) throws DAOException;
	public Collection<LivroAutor> pesquisarByAutor(Autor a) throws DAOException;
}
