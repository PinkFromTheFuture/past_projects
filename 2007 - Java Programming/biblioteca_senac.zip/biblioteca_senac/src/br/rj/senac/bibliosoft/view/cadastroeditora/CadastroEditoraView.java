package br.rj.senac.bibliosoft.view.cadastroeditora;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Rectangle;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.border.BevelBorder;

import br.rj.senac.bibliosoft.control.CadastroEditoraController;
import br.rj.senac.bibliosoft.model.Editora;

public class CadastroEditoraView extends JInternalFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel jContentPane = null;
	private JPanel jPanelCRUD = null;
	private JButton jbInserir = null;
	private JButton jbExcluir = null;
	private JButton jbGravar = null;
	private JButton jbCancelar = null;
	private JPanel jPanelFields = null;
	private JLabel jlNome = null;
	private JTextField jtfNome = null;
	private JTable jTableCRUD = null;
	private JButton jbEditar = null;
	
	private CadastroEditoraController editoraController = new CadastroEditoraController();  
	private Editora currentEditora;
	private EditoraTableModel editoraModel = new EditoraTableModel();
	
	/**
	 * This is the xxx default constructor
	 */
	public CadastroEditoraView() {
		super();
		initialize();
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		this.setTitle("Cadastro de Editora");
		this.setSize(new Dimension(795, 550));
		this.setContentPane(getJContentPane());
		
		jbInserir.setEnabled(true);
		jbExcluir.setEnabled(true);
		jbGravar.setEnabled(false);
		jbCancelar.setEnabled(false);
		jtfNome.setEnabled(false);
	}

	/**
	 * This method initializes jContentPane
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJContentPane() {
		if (jContentPane == null) {
			jContentPane = new JPanel();
			jContentPane.setLayout(null);
			jContentPane.add(getJPanelCRUD(), null);
			jContentPane.add(getJPanelFields(), null);
			jContentPane.add(getJTableCRUD(), null);
		}
		return jContentPane;
	}

	/**
	 * This method initializes jPanelCRUD	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getJPanelCRUD() {
		if (jPanelCRUD == null) {
			jPanelCRUD = new JPanel();
			jPanelCRUD.setLayout(new FlowLayout());
			jPanelCRUD.setBounds(new Rectangle(17, 15, 510, 39));
			jPanelCRUD.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));
			jPanelCRUD.add(getJbInserir(), null);
			jPanelCRUD.add(getJbExcluir(), null);
			jPanelCRUD.add(getJbEditar(), null);
			jPanelCRUD.add(getJbGravar(), null);
			jPanelCRUD.add(getJbCancelar(), null);
		}
		return jPanelCRUD;
	}

	/**
	 * This method initializes jbInserir	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJbInserir() {
		if (jbInserir == null) {
			jbInserir = new JButton();
			jbInserir.setText("Inserir");
			jbInserir.setPreferredSize(new Dimension(85, 26));
			jbInserir.setName("jbInserir");
			jbInserir.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					jbInserir.setEnabled(false);
					jbExcluir.setEnabled(false);
					jbEditar.setEnabled(false);
					jbGravar.setEnabled(true);
					jbCancelar.setEnabled(true);
					jtfNome.setEnabled(true);
					jtfNome.setFocusable(true);
					jtfNome.setText("");
					
					currentEditora = new Editora();
					
				}
			});
		}
		return jbInserir;
	}

	/**
	 * This method initializes jbExcluir	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJbExcluir() {
		if (jbExcluir == null) {
			jbExcluir = new JButton();
			jbExcluir.setText("Excluir");
			jbExcluir.setPreferredSize(new Dimension(85, 26));
			jbExcluir.setName("jbExcluir");
			jbExcluir.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					jbInserir.setEnabled(true);
					jbExcluir.setEnabled(true);
					jbEditar.setEnabled(true);
					jbGravar.setEnabled(false);
					jbCancelar.setEnabled(false);
					jtfNome.setEnabled(true);
					jtfNome.setFocusable(true);
				}
			});
		}
		return jbExcluir;
	}

	/**
	 * This method initializes jbGravar	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJbGravar() {
		if (jbGravar == null) {
			jbGravar = new JButton();
			jbGravar.setText("Gravar");
			jbGravar.setPreferredSize(new Dimension(85, 26));
			jbGravar.setName("jbGravar");
			jbGravar.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					jbInserir.setEnabled(true);
					jbExcluir.setEnabled(true);
					jbEditar.setEnabled(true);
					jbGravar.setEnabled(false);
					jbCancelar.setEnabled(false);
					jtfNome.setEnabled(false);
					jtfNome.setFocusable(false);
					
					currentEditora.setNome(jtfNome.getText());
					
					try {
						if (currentEditora.getId() == null) {
							editoraController.inserirEditora(currentEditora);
							editoraModel.addRow(currentEditora);
						} else {
							editoraController.alterarEditora(currentEditora);
						}
					} catch (Exception ex) {
						JOptionPane.showMessageDialog(null, ex.getMessage());
					}
										
				}
			});
		}
		return jbGravar;
	}

	/**
	 * This method initializes jbCancelar	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJbCancelar() {
		if (jbCancelar == null) {
			jbCancelar = new JButton();
			jbCancelar.setText("Cancelar");
			jbCancelar.setName("jbCancelar");
			jbCancelar.addActionListener(new java.awt.event.ActionListener() {   
				public void actionPerformed(java.awt.event.ActionEvent e) {    
					jbInserir.setEnabled(true);
					jbExcluir.setEnabled(true);
					jbEditar.setEnabled(true);
					jbGravar.setEnabled(false);
					jbCancelar.setEnabled(false);
					jtfNome.setEnabled(false);
					jtfNome.setFocusable(false);
				}
			
			});
		}
		return jbCancelar;
	}

	/**
	 * This method initializes jPanelFields	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getJPanelFields() {
		if (jPanelFields == null) {
			jlNome = new JLabel();
			jlNome.setText("Nome:");
			jPanelFields = new JPanel();
			jPanelFields.setLayout(new FlowLayout());
			jPanelFields.setBounds(new Rectangle(17, 136, 409, 37));
			jPanelFields.add(jlNome, null);
			jPanelFields.add(getJtfNome(), null);
		}
		return jPanelFields;
	}

	/**
	 * This method initializes jtfNome	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getJtfNome() {
		if (jtfNome == null) {
			jtfNome = new JTextField();
			jtfNome.setPreferredSize(new Dimension(300, 30));
		}
		return jtfNome;
	}

	/**
	 * This method initializes jTableCRUD	
	 * 	
	 * @return javax.swing.JTable	
	 */
	private JTable getJTableCRUD() {
		
		if (jTableCRUD == null) {
			
			jTableCRUD = new JTable();
			jTableCRUD.setBounds(new Rectangle(18, 199, 748, 304));
			jTableCRUD.setIntercellSpacing(new Dimension(10, 10));
			jTableCRUD.setModel(editoraModel);
			jTableCRUD.setBackground(Color.white);
			jTableCRUD.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
			
			try {
				
				editoraModel.setLinhas(editoraController.pesquisarEditora(null));
			} catch (Exception ex) {
				JOptionPane.showMessageDialog(null, ex.getMessage());
			}	
		}
		
		return jTableCRUD;
	}

	/**
	 * This method initializes jbEditar	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJbEditar() {
		if (jbEditar == null) {
			jbEditar = new JButton();
			jbEditar.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					jbInserir.setEnabled(false);
					jbExcluir.setEnabled(false);
					jbEditar.setEnabled(false);
					jbGravar.setEnabled(true);
					jbCancelar.setEnabled(true);
					jtfNome.setEnabled(true);
					jtfNome.setFocusable(true);
				}
			});
			jbEditar.setName("jbEditar");
			jbEditar.setPreferredSize(new Dimension(85, 26));
			jbEditar.setText("Editar");
		}
		return jbEditar;
	}

}  //  @jve:decl-index=0:visual-constraint="10,10"
