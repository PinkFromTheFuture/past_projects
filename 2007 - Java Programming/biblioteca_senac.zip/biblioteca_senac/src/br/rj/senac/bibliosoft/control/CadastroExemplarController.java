package br.rj.senac.bibliosoft.control;

import java.util.List;

import br.rj.senac.bibliosoft.exception.BusinessException;
import br.rj.senac.bibliosoft.exception.DatabaseException;
import br.rj.senac.bibliosoft.model.Exemplar;
import br.rj.senac.bibliosoft.model.conexao.MyConnection;
import br.rj.senac.bibliosoft.model.dao.IExemplarDAO;
import br.rj.senac.bibliosoft.model.dao.factory.DAOFactory;

public class CadastroExemplarController extends BibliosoftController {

	private IExemplarDAO exemplarDAO = DAOFactory.getExemplarDAO();
	
	public CadastroExemplarController() {
		
	}
	
	public void inserirExemplar(Exemplar exemplar) throws BusinessException, DatabaseException {
		try {
			
			MyConnection.beginTransaction();
			exemplarDAO.inserir(exemplar);
			MyConnection.commit();
			
		} catch (Exception e) {
			super.doRollback(e);
		}
	}
	
	public void excluirExemplar(Exemplar exemplar) throws BusinessException, DatabaseException {
		try {
			
			MyConnection.beginTransaction();
			exemplarDAO.excluir(exemplar);
			MyConnection.commit();
			
		} catch (Exception e) {
			
			super.doRollback(e);
		}
	}
	
	public void alterarExemplar(Exemplar exemplar) throws BusinessException, DatabaseException {
		try {
			
			MyConnection.beginTransaction();
			exemplarDAO.alterar(exemplar);
			MyConnection.commit();
			
		} catch (Exception e) {
			
			super.doRollback(e);
		}
	}
	
	public List<Exemplar> pesquisarExemplar(Exemplar exemplar) throws BusinessException, DatabaseException {
		try {
			
			return exemplarDAO.pesquisar(exemplar);
			
		} catch (Exception e) {
			
			super.doRollback(e);
			
			return null;
		}
	}
	
	public Exemplar pesquisarExemplarById(Long id) throws BusinessException, DatabaseException {
		try {
			
			return exemplarDAO.pesquisarById(id);
			
		} catch (Exception e) {
			
			super.doRollback(e);
			
			return null;
		}
	}
}
