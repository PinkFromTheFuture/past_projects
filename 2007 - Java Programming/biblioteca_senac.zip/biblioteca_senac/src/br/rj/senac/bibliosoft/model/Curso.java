package br.rj.senac.bibliosoft.model;

public class Curso extends EntityModel {

	private Long id;
	private String nome;
	
	public Curso() {
		
	}
	
	public Long getId() {
		return id;
	}
	
	public void setId(Long cursoId) {
		this.id = cursoId;
	}
	
	public String getNome() {
		return nome;
	}
	
	public void setNome(String nome) {
		this.nome = nome;
	}
}
