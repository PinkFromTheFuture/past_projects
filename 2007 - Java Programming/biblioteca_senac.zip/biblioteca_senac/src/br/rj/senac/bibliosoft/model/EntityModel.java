package br.rj.senac.bibliosoft.model;

/**
 * 
 * Classe pai de todas as classes de modelo de dom�nio.
 * Esta classe ajuda a facilitar a manuten��o do sistema e tamb�m no uso do 
 * polimorfismo, poupando escrever linhas de c�digo desnecess�rias.
 *
 */
public abstract class EntityModel {

}
