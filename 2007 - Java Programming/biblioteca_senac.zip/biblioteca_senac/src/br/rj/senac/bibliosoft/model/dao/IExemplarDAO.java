package br.rj.senac.bibliosoft.model.dao;

import java.util.List;

import br.rj.senac.bibliosoft.exception.DAOException;
import br.rj.senac.bibliosoft.model.Exemplar;

public interface IExemplarDAO extends IBibliosoftDAO {
	public Exemplar pesquisarById(Long exemplarId) throws DAOException;
	public List<Exemplar> pesquisar(Exemplar exemplar) throws DAOException;
}
