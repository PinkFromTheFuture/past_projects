package br.rj.senac.bibliosoft.control;

import java.util.List;

import br.rj.senac.bibliosoft.exception.BusinessException;
import br.rj.senac.bibliosoft.exception.DatabaseException;
import br.rj.senac.bibliosoft.model.Autor;
import br.rj.senac.bibliosoft.model.conexao.MyConnection;
import br.rj.senac.bibliosoft.model.dao.IAutorDAO;
import br.rj.senac.bibliosoft.model.dao.factory.DAOFactory;

public class CadastroAutorController extends BibliosoftController {

	private IAutorDAO autorDAO = DAOFactory.getAutorDAO();
	
	public CadastroAutorController() {
		
	}
	
	public void inserirAutor(Autor autor) throws BusinessException, DatabaseException {
		try {
			
			MyConnection.beginTransaction();
			autorDAO.inserir(autor);
			MyConnection.commit();
			
		} catch (Exception e) {
			super.doRollback(e);
		}
	}
	
	public void excluirAutor(Autor autor) throws BusinessException, DatabaseException {
		try {
			
			MyConnection.beginTransaction();
			autorDAO.excluir(autor);
			MyConnection.commit();
			
		} catch (Exception e) {
			
			super.doRollback(e);
		}
	}
	
	public void alterarAutor(Autor autor) throws BusinessException, DatabaseException {
		try {
			
			MyConnection.beginTransaction();
			autorDAO.alterar(autor);
			MyConnection.commit();
			
		} catch (Exception e) {
			
			super.doRollback(e);
		}
	}
	
	public List<Autor> pesquisarAutor(Autor autor) throws BusinessException, DatabaseException {
		try {
			
			return autorDAO.pesquisar(autor);
			
		} catch (Exception e) {
			
			super.doRollback(e);
			
			return null;
		}
	}
}
