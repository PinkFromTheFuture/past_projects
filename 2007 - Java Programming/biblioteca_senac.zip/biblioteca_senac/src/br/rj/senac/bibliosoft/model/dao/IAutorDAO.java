package br.rj.senac.bibliosoft.model.dao;

import java.util.List;

import br.rj.senac.bibliosoft.exception.DAOException;
import br.rj.senac.bibliosoft.model.Autor;

public interface IAutorDAO extends IBibliosoftDAO {
	public Autor pesquisarById(Long autorId) throws DAOException;
	public List<Autor> pesquisar(Autor autor) throws DAOException;
}
