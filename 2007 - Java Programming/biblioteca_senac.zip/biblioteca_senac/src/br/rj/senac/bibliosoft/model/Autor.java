package br.rj.senac.bibliosoft.model;


public class Autor extends EntityModel {

	private Long id;
	private String nome;
	
	public Autor() {
		
	}
	
	public Long getId() {
		return id;
	}
	
	public void setId(Long autorId) {
		this.id = autorId;
	}
	
	public String getNome() {
		return nome;
	}
	
	public void setNome(String nome) {
		this.nome = nome;
	}
}
