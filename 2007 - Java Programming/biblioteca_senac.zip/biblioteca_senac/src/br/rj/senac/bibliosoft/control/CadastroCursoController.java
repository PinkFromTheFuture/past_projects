package br.rj.senac.bibliosoft.control;

import java.util.List;

import br.rj.senac.bibliosoft.exception.BusinessException;
import br.rj.senac.bibliosoft.exception.DatabaseException;
import br.rj.senac.bibliosoft.model.Curso;
import br.rj.senac.bibliosoft.model.conexao.MyConnection;
import br.rj.senac.bibliosoft.model.dao.ICursoDAO;
import br.rj.senac.bibliosoft.model.dao.factory.DAOFactory;

public class CadastroCursoController extends BibliosoftController {

	private ICursoDAO cursoDAO = DAOFactory.getCursoDAO();
	
	public CadastroCursoController() {
		
	}
	
	public void inserirCurso(Curso curso) throws BusinessException, DatabaseException {
		try {
			
			MyConnection.beginTransaction();
			cursoDAO.inserir(curso);
			MyConnection.commit();
			
		} catch (Exception e) {
			super.doRollback(e);
		}
	}
	
	public void excluirCurso(Curso curso) throws BusinessException, DatabaseException {
		try {
			
			MyConnection.beginTransaction();
			cursoDAO.excluir(curso);
			MyConnection.commit();
			
		} catch (Exception e) {
			
			super.doRollback(e);
		}
	}
	
	public void alterarCurso(Curso curso) throws BusinessException, DatabaseException {
		try {
			
			MyConnection.beginTransaction();
			cursoDAO.alterar(curso);
			MyConnection.commit();
			
		} catch (Exception e) {
			
			super.doRollback(e);
		}
	}
	
	public List<Curso> pesquisarCurso(Curso curso) throws BusinessException, DatabaseException {
		try {
			
			return cursoDAO.pesquisar(curso);
			
		} catch (Exception e) {
			
			super.doRollback(e);
			
			return null;
		}
	}
}
