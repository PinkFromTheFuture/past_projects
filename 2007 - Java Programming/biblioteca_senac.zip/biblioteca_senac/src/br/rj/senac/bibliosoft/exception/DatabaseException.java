package br.rj.senac.bibliosoft.exception;


/**
 * 
 * Exce��o lan�ada pela camada Controller quando ocorrer uma exce��o do tipo 
 * DAOException da camada DAO.
 * 
 * Esta exce��o � gerada a partir da captura de uma exce��o do tipo DAOException.
 * 
 * � lan�ada da camada Controller e capturada na camada View.
 *
 */
public class DatabaseException extends Exception {

	public DatabaseException(String msg) {
		super(msg);
	}
	
	public DatabaseException(Exception e) {
		super(e);
	}
	
	public DatabaseException(String msg, Exception e) {
		super(msg, e);
	}
}
