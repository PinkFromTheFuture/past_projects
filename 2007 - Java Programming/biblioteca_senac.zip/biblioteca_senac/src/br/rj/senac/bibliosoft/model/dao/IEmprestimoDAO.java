package br.rj.senac.bibliosoft.model.dao;

import java.util.List;

import br.rj.senac.bibliosoft.exception.DAOException;
import br.rj.senac.bibliosoft.model.Emprestimo;
import br.rj.senac.bibliosoft.model.Usuario;

public interface IEmprestimoDAO extends IBibliosoftDAO {
	
	public Emprestimo pesquisarById(Long emprestimoId) throws DAOException;
	public List<Emprestimo> pesquisar(Emprestimo emprestimo) throws DAOException;
	public List<Emprestimo> pesquisarByUsuario(Usuario usuario, Boolean emAberto) throws DAOException;
	
}
