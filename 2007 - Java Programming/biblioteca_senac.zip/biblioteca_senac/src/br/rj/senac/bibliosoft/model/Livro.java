package br.rj.senac.bibliosoft.model;

public class Livro extends EntityModel {

	private Long id;
	private String nome;
	private String isbn;
	private Editora editora;
	
	public Livro() {
		
	}
	
	public Long getId() {
		return id;
	}
	
	public void setId(Long livroId) {
		this.id = livroId;
	}
	
	public String getNome() {
		return nome;
	}
	
	public void setNome(String nome) {
		this.nome = nome;
	}
	
	public String getIsbn() {
		return isbn;
	}
	
	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}
	
	public Editora getEditora() {
		return editora;
	}
	
	public void setEditora(Editora editora) {
		this.editora = editora;
	}
}
