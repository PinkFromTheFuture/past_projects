package br.rj.senac.bibliosoft.control;

import java.util.List;

import br.rj.senac.bibliosoft.exception.BusinessException;
import br.rj.senac.bibliosoft.exception.DatabaseException;
import br.rj.senac.bibliosoft.model.Livro;
import br.rj.senac.bibliosoft.model.conexao.MyConnection;
import br.rj.senac.bibliosoft.model.dao.ILivroDAO;
import br.rj.senac.bibliosoft.model.dao.factory.DAOFactory;

public class CadastroLivroController extends BibliosoftController {

	private ILivroDAO livroDAO = DAOFactory.getLivroDAO();
	
	public CadastroLivroController() {
		
	}
	
	public void inserirLivro(Livro livro) throws BusinessException, DatabaseException {
		try {
			
			MyConnection.beginTransaction();
			livroDAO.inserir(livro);
			MyConnection.commit();
			
		} catch (Exception e) {
			super.doRollback(e);
		}
	}
	
	public void excluirLivro(Livro livro) throws BusinessException, DatabaseException {
		try {
			
			MyConnection.beginTransaction();
			livroDAO.excluir(livro);
			MyConnection.commit();
			
		} catch (Exception e) {
			
			super.doRollback(e);
		}
	}
	
	public void alterarLivro(Livro livro) throws BusinessException, DatabaseException {
		try {
			
			MyConnection.beginTransaction();
			livroDAO.alterar(livro);
			MyConnection.commit();
			
		} catch (Exception e) {
			
			super.doRollback(e);
		}
	}
	
	public List<Livro> pesquisarLivro(Livro livro) throws BusinessException, DatabaseException {
		try {
			
			return livroDAO.pesquisar(livro);
			
		} catch (Exception e) {
			
			super.doRollback(e);
			
			return null;
		}
	}
}
