package br.rj.senac.bibliosoft.model.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Collection;

import br.rj.senac.bibliosoft.exception.DAOException;
import br.rj.senac.bibliosoft.model.Autor;
import br.rj.senac.bibliosoft.model.Livro;
import br.rj.senac.bibliosoft.model.LivroAutor;
import br.rj.senac.bibliosoft.model.conexao.MyConnection;
import br.rj.senac.bibliosoft.model.dao.IAutorDAO;
import br.rj.senac.bibliosoft.model.dao.ILivroAutorDAO;
import br.rj.senac.bibliosoft.model.dao.ILivroDAO;
import br.rj.senac.bibliosoft.model.dao.factory.DAOFactory;

public class LivroAutorJdbcDAO implements ILivroAutorDAO {

	private ILivroDAO livroDAO = DAOFactory.getLivroDAO();
	private IAutorDAO autorDAO = DAOFactory.getAutorDAO();
	
	public void excluir(LivroAutor la) throws DAOException {
		try {
			if (la != null) {
				
				String sql = 
						"DELETE FROM LIVRO_AUTOR " +
						"WHERE LIVRO_ID = ? " +
						"  AND AUTOR_ID = ? ";
				
				Connection conn = MyConnection.getConnection();
				PreparedStatement ps = conn.prepareStatement(sql);

				ps.setLong(1, la.getLivro().getId());
				ps.setLong(2, la.getAutor().getId());
				
				ps.executeUpdate();
				
				ps.close();
			}
			
		} catch (Exception e) {
			throw new DAOException(e);
		}
	}

	public void inserir(LivroAutor la) throws DAOException {
		try {	
			if (la != null) {
				
				String sql = "INSERT INTO LIVRO_AUTOR(LIVRO_ID, AUTOR_ID) VALUES (?, ?) ";
				
				Connection conn = MyConnection.getConnection();
				PreparedStatement ps = conn.prepareStatement(sql);

				ps.setLong(1, la.getLivro().getId());
				ps.setLong(2, la.getAutor().getId());
				
				ps.executeUpdate();
				
				ps.close();
			}
			
		} catch (Exception e) {
			throw new DAOException(e);
		}
	}

	public Collection<LivroAutor> pesquisarByLivro(Livro l) throws DAOException {
		try {
			
			Collection<LivroAutor> col = new ArrayList<LivroAutor>();
			if (l != null) {
				
				String sql = "SELECT * FROM LIVRO_AUTOR WHERE 1 = 1 ";
				
				if (l.getId() != null) {
					sql += " AND LIVRO_ID = ? ";
				}
				
				Connection conn = MyConnection.getConnection();
				PreparedStatement ps = conn.prepareStatement(sql);

				if (l.getId() != null) { 
					ps.setLong(1, l.getId());	
				}
				
				Livro livro = livroDAO.pesquisarById(l.getId());
				
				ResultSet rs = ps.executeQuery();

				while (rs.next()) {
					LivroAutor la = new LivroAutor();
					
					la.setAutor( autorDAO.pesquisarById(rs.getLong("AUTOR_ID")) );
					la.setLivro(livro);
					
					col.add(la);
				}
			}
			
			return col;
			
		} catch (Exception e) {
			throw new DAOException(e);
		}
	}

	public Collection<LivroAutor> pesquisarByAutor(Autor a) throws DAOException {
		try {
			
			Collection<LivroAutor> col = new ArrayList<LivroAutor>();
			if (a != null) {
				
				String sql = "SELECT * FROM LIVRO_AUTOR WHERE 1 = 1 ";
				
				if (a.getId() != null) {
					sql += " AND AUTOR_ID = ? ";
				}
				
				Connection conn = MyConnection.getConnection();
				PreparedStatement ps = conn.prepareStatement(sql);

				if (a.getId() != null) { 
					ps.setLong(1, a.getId());	
				}
				
				Autor autor = autorDAO.pesquisarById(a.getId());
				
				ResultSet rs = ps.executeQuery();
				
				while (rs.next()) {
					LivroAutor la = new LivroAutor();
					
					la.setAutor( autor );
					la.setLivro( livroDAO.pesquisarById(rs.getLong("LIVRO_ID")) );
					
					col.add(la);
				}
			}
			
			return col;
			
		} catch (Exception e) {
			throw new DAOException(e);
		}
	}
}
