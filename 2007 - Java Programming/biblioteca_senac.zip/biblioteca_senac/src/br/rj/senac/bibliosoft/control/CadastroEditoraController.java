package br.rj.senac.bibliosoft.control;

import java.util.List;

import br.rj.senac.bibliosoft.exception.BusinessException;
import br.rj.senac.bibliosoft.exception.DatabaseException;
import br.rj.senac.bibliosoft.model.Editora;
import br.rj.senac.bibliosoft.model.conexao.MyConnection;
import br.rj.senac.bibliosoft.model.dao.IEditoraDAO;
import br.rj.senac.bibliosoft.model.dao.factory.DAOFactory;

public class CadastroEditoraController extends BibliosoftController {

	private IEditoraDAO editoraDAO = DAOFactory.getEditoraDAO();
	
	public CadastroEditoraController() {
		
	}
	
	public void inserirEditora(Editora editora) throws BusinessException, DatabaseException {
		try {
			
			MyConnection.beginTransaction();
			editoraDAO.inserir(editora);
			MyConnection.commit();
			
		} catch (Exception e) {
			super.doRollback(e);
		}
	}
	
	public void excluirEditora(Editora editora) throws BusinessException, DatabaseException {
		try {
			
			MyConnection.beginTransaction();
			editoraDAO.excluir(editora);
			MyConnection.commit();
			
		} catch (Exception e) {
			
			super.doRollback(e);
		}
	}
	
	public void alterarEditora(Editora editora) throws BusinessException, DatabaseException {
		try {
			
			MyConnection.beginTransaction();
			editoraDAO.alterar(editora);
			MyConnection.commit();
			
		} catch (Exception e) {
			
			super.doRollback(e);
		}
	}
	
	public List<Editora> pesquisarEditora(Editora editora) throws BusinessException, DatabaseException {
		try {
			
			return editoraDAO.pesquisar(editora);
			
		} catch (Exception e) {
			
			super.doRollback(e);
			
			return null;
		}
	}
}
