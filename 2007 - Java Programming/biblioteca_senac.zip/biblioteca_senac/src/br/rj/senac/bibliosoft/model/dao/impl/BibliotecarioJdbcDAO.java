package br.rj.senac.bibliosoft.model.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import br.rj.senac.bibliosoft.exception.DAOException;
import br.rj.senac.bibliosoft.model.Bibliotecario;
import br.rj.senac.bibliosoft.model.EntityModel;
import br.rj.senac.bibliosoft.model.conexao.MyConnection;
import br.rj.senac.bibliosoft.model.dao.IBibliotecarioDAO;

public class BibliotecarioJdbcDAO implements IBibliotecarioDAO {
	
	public void alterar(EntityModel em) throws DAOException {
		try {	
			if (em != null) {
				
				Bibliotecario bibliotecario = (Bibliotecario)em;
				
				String sql = "UPDATE BIBLIOTECARIO " +
						"SET NOME = ?, USUARIO = ?, SENHA = ? WHERE BIBLIOTECARIO_ID = ? ";
				
				Connection conn = MyConnection.getConnection();
				PreparedStatement ps = conn.prepareStatement(sql);
				
				ps.setString(1, bibliotecario.getNome());
				ps.setString(2, bibliotecario.getUsuario());
				ps.setString(3, bibliotecario.getSenha());
				ps.setLong(4, bibliotecario.getId());
				
				ps.executeUpdate();
				
				ps.close();
			}
			
		} catch (Exception e) {
			throw new DAOException(e);
		}
	}

	public void excluir(EntityModel em) throws DAOException {
		try {	
			if (em != null) {
				
				Bibliotecario bibliotecario = (Bibliotecario)em;
				
				String sql = "DELETE FROM BIBLIOTECARIO WHERE BIBLIOTECARIO_ID = ? ";
				
				Connection conn = MyConnection.getConnection();
				PreparedStatement ps = conn.prepareStatement(sql);

				ps.setLong(1, bibliotecario.getId());
				
				ps.executeUpdate();
				
				ps.close();
			}
			
		} catch (Exception e) {
			throw new DAOException(e);
		}
	}

	public void inserir(EntityModel em) throws DAOException {
		try {	
			if (em != null) {
				
				Bibliotecario bibliotecario = (Bibliotecario)em;
				
				String sql = "INSERT INTO BIBLIOTECARIO(NOME, USUARIO, SENHA) VALUES (?, ?, ?) ";
				
				Connection conn = MyConnection.getConnection();
				PreparedStatement ps = conn.prepareStatement(sql);

				ps.setString(1, bibliotecario.getNome());
				ps.setString(2, bibliotecario.getUsuario());
				ps.setString(3, bibliotecario.getSenha());
				
				ps.executeUpdate();
				
				ps.close();
			}
			
		} catch (Exception e) {
			throw new DAOException(e);
		}
	}

	public List<Bibliotecario> pesquisar(Bibliotecario bibliotecario) throws DAOException {
		try {
			
			List<Bibliotecario> col = new ArrayList<Bibliotecario>();
				
			String sql = 
				"SELECT * FROM BIBLIOTECARIO WHERE 1 = 1 ";
			
			if (bibliotecario != null && bibliotecario.getNome() != null) {
				sql += " AND NOME LIKE ? ";
			}
			
			if (bibliotecario != null && bibliotecario.getUsuario() != null) {
				sql += " AND USUARIO LIKE ? ";
			}
			
			Connection conn = MyConnection.getConnection();
			PreparedStatement ps = conn.prepareStatement(sql);

			int posicao = 1;
			if (bibliotecario != null && bibliotecario.getNome() != null) { 
				ps.setString(posicao, bibliotecario.getNome());
				posicao++;
			}
			
			if (bibliotecario != null && bibliotecario.getUsuario() != null) { 
				ps.setString(posicao, bibliotecario.getUsuario());
			}
			
			ResultSet rs = ps.executeQuery();
			
			while (rs.next()) {
				Bibliotecario bibliotec = new Bibliotecario();
				bibliotec.setId(rs.getLong("BIBLIOTECARIO_ID"));
				bibliotec.setNome(rs.getString("NOME"));
				bibliotec.setUsuario(rs.getString("USUARIO"));
				bibliotec.setSenha(rs.getString("SENHA"));
				
				col.add(bibliotec);
			}
			
			return col;
			
		} catch (Exception e) {
			throw new DAOException(e);
		}
	}
	
	public Bibliotecario pesquisarById(Long bibliotecarioId) throws DAOException {
		Bibliotecario bibliotecario = null;
		
		try {
			if (bibliotecarioId != null) {				

				String sql = "SELECT * FROM BIBLIOTECARIO WHERE BIBLIOTECARIO_ID = ? ";
				
				Connection conn = MyConnection.getConnection();
				PreparedStatement ps = conn.prepareStatement(sql); 
				ps.setLong(1, bibliotecarioId);
				
				ResultSet rs = ps.executeQuery();		
				
				if (rs.next()) {
					bibliotecario = new Bibliotecario();
					bibliotecario.setId(rs.getLong("BIBLIOTECARIO_ID"));
					bibliotecario.setNome(rs.getString("NOME"));
					bibliotecario.setUsuario(rs.getString("USUARIO"));
					bibliotecario.setSenha(rs.getString("SENHA"));
				}
			}
			
			return bibliotecario;
			
		} catch (Exception e) {
			throw new DAOException(e);
		}
	}
}
