package br.rj.senac.bibliosoft.model;

public class UsuarioCurso extends EntityModel {

	private Usuario usuario;
	private Curso curso;
	
	public UsuarioCurso() {
		
	}
	
	public Usuario getUsuario() {
		return usuario;
	}
	
	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}
	
	public Curso getCurso() {
		return curso;
	}
	
	public void setCurso(Curso curso) {
		this.curso = curso;
	}
}
