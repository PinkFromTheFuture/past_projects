package br.rj.senac.bibliosoft.model.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import br.rj.senac.bibliosoft.exception.DAOException;
import br.rj.senac.bibliosoft.model.EntityModel;
import br.rj.senac.bibliosoft.model.Usuario;
import br.rj.senac.bibliosoft.model.conexao.MyConnection;
import br.rj.senac.bibliosoft.model.dao.IUsuarioDAO;

public class UsuarioJdbcDAO implements IUsuarioDAO {
	
	public void alterar(EntityModel em) throws DAOException {
		try {	
			if (em != null) {
				
				Usuario usuario = (Usuario)em;
				
				String sql = "UPDATE USUARIO SET NOME = ?, MATRICULA = ? WHERE USUARIO_ID = ? ";
				
				Connection conn = MyConnection.getConnection();
				PreparedStatement ps = conn.prepareStatement(sql);
				
				ps.setString(1, usuario.getNome());
				ps.setString(2, usuario.getMatricula());
				ps.setLong(3, usuario.getId());
				
				ps.executeUpdate();
				
				ps.close();
			}
			
		} catch (Exception e) {
			throw new DAOException(e);
		}
	}

	public void excluir(EntityModel em) throws DAOException {
		try {	
			if (em != null) {
				
				Usuario usuario = (Usuario)em;
				
				String sql = "DELETE FROM USUARIO WHERE USUARIO_ID = ? ";
				
				Connection conn = MyConnection.getConnection();
				PreparedStatement ps = conn.prepareStatement(sql);

				ps.setLong(1, usuario.getId());
				
				ps.executeUpdate();
				
				ps.close();
			}
			
		} catch (Exception e) {
			throw new DAOException(e);
		}
	}

	public void inserir(EntityModel em) throws DAOException {
		try {	
			if (em != null) {
				
				Usuario usuario = (Usuario)em;
				
				String sql = "INSERT INTO USUARIO(NOME, MATRICULA) VALUES (?, ?) ";
				
				Connection conn = MyConnection.getConnection();
				PreparedStatement ps = conn.prepareStatement(sql);

				ps.setString(1, usuario.getNome());
				ps.setString(2, usuario.getMatricula());
				
				ps.executeUpdate();
				
				ps.close();
			}
			
		} catch (Exception e) {
			throw new DAOException(e);
		}
	}

	public List<Usuario> pesquisar(Usuario usuario) throws DAOException {
		try {
			
			List<Usuario> col = new ArrayList<Usuario>();
				
			String sql = "SELECT * FROM USUARIO WHERE 1 = 1 ";
			
			if (usuario != null && usuario.getNome() != null) {
				sql += " AND NOME LIKE ? ";
			}
			
			if (usuario != null && usuario.getMatricula() != null) {
				sql += " AND MATRICULA LIKE ? ";
			}
			
			Connection conn = MyConnection.getConnection();
			PreparedStatement ps = conn.prepareStatement(sql);

			int posicao = 1;
			if (usuario != null && usuario.getNome() != null) { 
				ps.setString(posicao, usuario.getNome());
				posicao++;
			}
			
			if (usuario != null && usuario.getMatricula() != null) { 
				ps.setString(posicao, usuario.getMatricula());
				posicao++;
			}
			
			ResultSet rs = ps.executeQuery();
			
			while (rs.next()) {
				Usuario usu = new Usuario();
				usu.setId(rs.getLong("USUARIO_ID"));
				usu.setNome(rs.getString("NOME"));
				usu.setMatricula(rs.getString("MATRICULA"));
				
				col.add(usu);
			}
			
			return col;
			
		} catch (Exception e) {
			throw new DAOException(e);
		}
	}
	
	public Usuario pesquisarById(Long usuarioId) throws DAOException {
		Usuario usuario = null;
		
		try {
			if (usuarioId != null) {				

				String sql = "SELECT * FROM USUARIO WHERE USUARIO_ID = ? ";
				
				Connection conn = MyConnection.getConnection();
				PreparedStatement ps = conn.prepareStatement(sql); 
				ps.setLong(1, usuarioId);
				
				ResultSet rs = ps.executeQuery();		
				
				if (rs.next()) {
					usuario = new Usuario();
					usuario.setId(rs.getLong("USUARIO_ID"));
					usuario.setNome(rs.getString("NOME"));
					usuario.setMatricula(rs.getString("MATRICULA"));
				}
			}
			
			return usuario;
			
		} catch (Exception e) {
			throw new DAOException(e);
		}
	}
}
