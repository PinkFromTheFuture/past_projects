package br.rj.senac.bibliosoft.model;

public class Emprestimo extends EntityModel {

	private Long id;
	private java.util.Date dataReserva;
	private java.util.Date dataEntrega;
	private Usuario usuario;
	private Exemplar exemplar;
	private Bibliotecario bibliotecario;
	
	public Emprestimo() {
		
	}
	
	public Long getId() {
		return id;
	}
	
	public void setId(Long emprestimoId) {
		this.id = emprestimoId;
	}
	
	public java.util.Date getDataReserva() {
		return dataReserva;
	}
	
	public void setDataReserva(java.util.Date dataReserva) {
		this.dataReserva = dataReserva;
	}
	
	public java.util.Date getDataEntrega() {
		return dataEntrega;
	}
	
	public void setDataEntrega(java.util.Date dataEntrega) {
		this.dataEntrega = dataEntrega;
	}
	
	public Usuario getUsuario() {
		return usuario;
	}
	
	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}
	
	public Exemplar getExemplar() {
		return exemplar;
	}
	
	public void setExemplar(Exemplar exemplar) {
		this.exemplar = exemplar;
	}
	
	public Bibliotecario getBibliotecario() {
		return bibliotecario;
	}
	
	public void setBibliotecario(Bibliotecario bibliotecario) {
		this.bibliotecario = bibliotecario;
	}
}
