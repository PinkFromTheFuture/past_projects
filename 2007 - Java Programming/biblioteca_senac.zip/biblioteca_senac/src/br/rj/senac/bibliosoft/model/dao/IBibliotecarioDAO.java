package br.rj.senac.bibliosoft.model.dao;

import java.util.List;

import br.rj.senac.bibliosoft.exception.DAOException;
import br.rj.senac.bibliosoft.model.Bibliotecario;

public interface IBibliotecarioDAO extends IBibliosoftDAO {
	public Bibliotecario pesquisarById(Long bibliotecarioId) throws DAOException;
	public List<Bibliotecario> pesquisar(Bibliotecario bibliotecario) throws DAOException;
}
