package br.rj.senac.bibliosoft.model.dao;

import java.util.List;

import br.rj.senac.bibliosoft.exception.DAOException;
import br.rj.senac.bibliosoft.model.Editora;

public interface IEditoraDAO extends IBibliosoftDAO {

	public Editora pesquisarById(Long editoraId) throws DAOException;
	public List<Editora> pesquisar(Editora editora) throws DAOException;
}
