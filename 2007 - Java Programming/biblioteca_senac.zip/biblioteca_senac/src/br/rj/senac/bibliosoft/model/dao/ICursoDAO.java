package br.rj.senac.bibliosoft.model.dao;

import java.util.List;

import br.rj.senac.bibliosoft.exception.DAOException;
import br.rj.senac.bibliosoft.model.Curso;

public interface ICursoDAO extends IBibliosoftDAO {
	public Curso pesquisarById(Long cursoId) throws DAOException;
	public List<Curso> pesquisar(Curso curso) throws DAOException;
}
