package br.rj.senac.bibliosoft.control;

import br.rj.senac.bibliosoft.exception.BusinessException;
import br.rj.senac.bibliosoft.exception.DAOException;
import br.rj.senac.bibliosoft.exception.DatabaseException;
import br.rj.senac.bibliosoft.model.conexao.MyConnection;


public class BibliosoftController {

	/**
	 * Isola o tratamento de rollback de todo o sistema em um �nico ponto, 
	 * facilitando a manuten��o.
	 * 
	 * @param e
	 * @throws DatabaseException
	 * @throws BusinessException
	 */
	public void doRollback(Exception e) throws DatabaseException, BusinessException {
		
		System.out.println(e.getStackTrace().toString() );
		
		MyConnection.rollback();
		
		if (e instanceof DAOException) {

			throw new DatabaseException("Ocorreu um erro ao efetuar uma opera��o com o banco de dados", e);
			
		} else if (e instanceof RuntimeException) {
			
			throw new BusinessException("Ocorreu um erro RUNTIME de programa��o! " +
					"Por favor contacte a equipe de suporte para que " +
					"possamos corrigir este erro. ", e);
			
		} else if (e instanceof BusinessException){
			throw (BusinessException)e;
		}
	}
}
