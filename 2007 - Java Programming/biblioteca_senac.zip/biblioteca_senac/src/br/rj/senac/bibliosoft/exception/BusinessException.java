package br.rj.senac.bibliosoft.exception;

/**
 * 
 * Exce��o lan�ada quando um regra de neg�cio do sistema for violada. 
 * 
 * Exemplo de regra de neg�cio:
 *  - Um usu�rio n�o pode efetuar mais do que 3 empr�stimos simultaneamente.
 *
 * � lan�ada da camada Controller e capturada na camada View.
 *
 */
public class BusinessException extends Exception {

	public BusinessException(String msg) {
		super(msg);
	}
	
	public BusinessException(Exception e) {
		super(e);
	}
	
	public BusinessException(String msg, Exception e) {
		super(msg, e);
	}
}
