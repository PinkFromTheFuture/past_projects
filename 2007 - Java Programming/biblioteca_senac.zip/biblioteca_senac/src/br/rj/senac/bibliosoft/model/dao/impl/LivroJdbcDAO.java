package br.rj.senac.bibliosoft.model.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import br.rj.senac.bibliosoft.exception.DAOException;
import br.rj.senac.bibliosoft.model.EntityModel;
import br.rj.senac.bibliosoft.model.Livro;
import br.rj.senac.bibliosoft.model.conexao.MyConnection;
import br.rj.senac.bibliosoft.model.dao.IEditoraDAO;
import br.rj.senac.bibliosoft.model.dao.ILivroDAO;
import br.rj.senac.bibliosoft.model.dao.factory.DAOFactory;

public class LivroJdbcDAO implements ILivroDAO {

	private IEditoraDAO editoraDAO = DAOFactory.getEditoraDAO();
	
	public void alterar(EntityModel em) throws DAOException {
		try {	
			if (em != null) {
				
				Livro livro = (Livro)em;
				
				String sql = "UPDATE LIVRO SET NOME = ?, ISBN = ?, EDITORA_ID = ? WHERE LIVRO_ID = ? ";
				
				Connection conn = MyConnection.getConnection();
				PreparedStatement ps = conn.prepareStatement(sql);
				
				ps.setString(1, livro.getNome());
				ps.setString(2, livro.getIsbn());
				ps.setLong(3, livro.getEditora().getId());
				ps.setLong(4, livro.getId());
				
				ps.executeUpdate();
				
				ps.close();
			}
			
		} catch (Exception e) {
			throw new DAOException(e);
		}
		
	}

	public void excluir(EntityModel em) throws DAOException {
		try {	
			if (em != null) {
				
				Livro livro = (Livro)em;
				
				String sql = "DELETE FROM LIVRO WHERE LIVRO_ID = ? ";
				
				Connection conn = MyConnection.getConnection();
				PreparedStatement ps = conn.prepareStatement(sql);

				ps.setLong(1, livro.getId());
				
				ps.executeUpdate();
				
				ps.close();
			}
			
		} catch (Exception e) {
			throw new DAOException(e);
		}
	}

	public void inserir(EntityModel em) throws DAOException {
		try {	
			if (em != null) {
				
				Livro livro = (Livro)em;
				
				String sql = "INSERT INTO LIVRO(NOME, ISBN, EDITORA_ID) VALUES (?, ?, ?) ";
				
				Connection conn = MyConnection.getConnection();
				PreparedStatement ps = conn.prepareStatement(sql);

				ps.setString(1, livro.getNome());
				ps.setString(2, livro.getIsbn());
				ps.setLong(3, livro.getEditora().getId());
				
				ps.executeUpdate();
				
				ps.close();
			}
			
		} catch (Exception e) {
			throw new DAOException(e);
		}
	}

	public List<Livro> pesquisar(Livro livro) throws DAOException {
		try {
			
			List<Livro> col = new ArrayList<Livro>();
				
			String sql = "SELECT * FROM LIVRO WHERE 1 = 1 ";
			
			if (livro != null && livro.getNome() != null) {
				sql += " AND NOME LIKE ? ";
			}
			
			if (livro != null && livro.getIsbn() != null) {
				sql += " AND ISBN LIKE ? ";
			}
			
			if (livro != null && livro.getEditora() != null && livro.getEditora().getId() != null) {
				sql += " AND EDITORA_ID = ? ";
			}
			
			Connection conn = MyConnection.getConnection();
			PreparedStatement ps = conn.prepareStatement(sql);

			int consulta = 1;
			if (livro != null && livro.getNome() != null) { 
				ps.setString(consulta, livro.getNome());
				consulta++;
			}
			
			if (livro != null && livro.getIsbn() != null) { 
				ps.setString(consulta, livro.getIsbn());
				consulta++;
			}
			
			if (livro != null && livro.getEditora() != null && livro.getEditora().getId() != null) { 
				ps.setString(consulta, livro.getNome());
				consulta++;
			}
			
			ResultSet rs = ps.executeQuery();
			
			while (rs.next()) {
				Livro l = new Livro();
				l.setId(rs.getLong("LIVRO_ID"));
				l.setNome(rs.getString("NOME"));
				l.setIsbn(rs.getString("ISBN"));
				l.setEditora(  editoraDAO.pesquisarById( rs.getLong("EDITORA_ID") ) );
				
				col.add(l);
			}
			
			return col;
			
		} catch (Exception e) {
			throw new DAOException(e);
		}
	}

	public Livro pesquisarById(Long livroId) throws DAOException {
		Livro livro = null;
		
		try {
			if (livroId != null) {				

				String sql = "SELECT * FROM USUARIO WHERE USUARIO_ID = ? ";
				
				Connection conn = MyConnection.getConnection();
				PreparedStatement ps = conn.prepareStatement(sql); 
				ps.setLong(1, livroId);
				
				ResultSet rs = ps.executeQuery();		
				
				if (rs.next()) {
					livro = new Livro();
					livro.setId(rs.getLong("LIVRO_ID"));
					livro.setNome(rs.getString("NOME"));
					livro.setIsbn(rs.getString("ISBN"));
					livro.setEditora(  editoraDAO.pesquisarById( rs.getLong("EDITORA_ID") ) );
				}
			}
			
			return livro;
			
		} catch (Exception e) {
			throw new DAOException(e);
		}
	}

}
