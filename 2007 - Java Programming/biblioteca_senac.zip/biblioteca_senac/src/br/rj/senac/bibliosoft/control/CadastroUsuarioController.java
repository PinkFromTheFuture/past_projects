package br.rj.senac.bibliosoft.control;

import java.util.List;

import br.rj.senac.bibliosoft.exception.BusinessException;
import br.rj.senac.bibliosoft.exception.DatabaseException;
import br.rj.senac.bibliosoft.model.Usuario;
import br.rj.senac.bibliosoft.model.conexao.MyConnection;
import br.rj.senac.bibliosoft.model.dao.IUsuarioDAO;
import br.rj.senac.bibliosoft.model.dao.factory.DAOFactory;

public class CadastroUsuarioController extends BibliosoftController {

	private IUsuarioDAO usuarioDAO = DAOFactory.getUsuarioDAO();
	
	public CadastroUsuarioController() {
		
	}
	
	public void inserirUsuario(Usuario usuario) throws BusinessException, DatabaseException {
		try {
			
			MyConnection.beginTransaction();
			usuarioDAO.inserir(usuario);
			MyConnection.commit();
			
		} catch (Exception e) {
			super.doRollback(e);
		}
	}
	
	public void excluirUsuario(Usuario usuario) throws BusinessException, DatabaseException {
		try {
			
			MyConnection.beginTransaction();
			usuarioDAO.excluir(usuario);
			MyConnection.commit();
			
		} catch (Exception e) {
			
			super.doRollback(e);
		}
	}
	
	public void alterarUsuario(Usuario usuario) throws BusinessException, DatabaseException {
		try {
			
			MyConnection.beginTransaction();
			usuarioDAO.alterar(usuario);
			MyConnection.commit();
			
		} catch (Exception e) {
			
			super.doRollback(e);
		}
	}
	
	public List<Usuario> pesquisarUsuario(Usuario usuario) throws BusinessException, DatabaseException {
		try {
			
			return usuarioDAO.pesquisar(usuario);
			
		} catch (Exception e) {
			
			super.doRollback(e);
			
			return null;
		}
	}
	
	public Usuario pesquisarUsuarioById(Long id) throws BusinessException, DatabaseException {
		try {
			
			return usuarioDAO.pesquisarById(id);
			
		} catch (Exception e) {
			
			super.doRollback(e);
			
			return null;
		}
	}
}
