package br.rj.senac.bibliosoft.model.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import br.rj.senac.bibliosoft.exception.DAOException;
import br.rj.senac.bibliosoft.model.Autor;
import br.rj.senac.bibliosoft.model.EntityModel;
import br.rj.senac.bibliosoft.model.conexao.MyConnection;
import br.rj.senac.bibliosoft.model.dao.IAutorDAO;

public class AutorJdbcDAO implements IAutorDAO {
	
	public void alterar(EntityModel em) throws DAOException {
		try {
			if (em != null) {
				
				Autor autor = (Autor)em;
				
				String sql = "UPDATE AUTOR SET NOME = ? WHERE AUTOR_ID = ? ";
				
				Connection conn = MyConnection.getConnection();
				PreparedStatement ps = conn.prepareStatement(sql);
				
				ps.setString(1, autor.getNome());
				ps.setLong(2, autor.getId());
				
				ps.executeUpdate();
				
				ps.close();
			}
			
		} catch (Exception e) {
			throw new DAOException(e);
		}
	}

	public void excluir(EntityModel em) throws DAOException {
		try {	
			if (em != null) {
				
				Autor autor = (Autor)em;
				
				String sql = "DELETE FROM AUTOR WHERE AUTOR_ID = ? ";
				
				Connection conn = MyConnection.getConnection();
				PreparedStatement ps = conn.prepareStatement(sql);

				ps.setLong(1, autor.getId());
				
				ps.executeUpdate();
				
				ps.close();
			}
			
		} catch (Exception e) {
			throw new DAOException(e);
		}
	}

	public void inserir(EntityModel em) throws DAOException {
		try {	
			if (em != null) {
				
				Autor autor = (Autor)em;
				
				String sql = "INSERT INTO AUTOR(NOME) VALUES (?) ";
				
				Connection conn = MyConnection.getConnection();
				PreparedStatement ps = conn.prepareStatement(sql);

				ps.setString(1, autor.getNome());
				
				ps.executeUpdate();
				
				ps.close();
			}
			
		} catch (Exception e) {
			throw new DAOException(e);
		}
	}

	public List<Autor> pesquisar(Autor autor) throws DAOException {
		try {
			
			List<Autor> col = new ArrayList<Autor>();
			
			String sql = "SELECT * FROM AUTOR WHERE 1 = 1 ";
			
			if (autor != null && autor.getNome() != null) {
				sql += " AND NOME LIKE ? ";
			}
			
			Connection conn = MyConnection.getConnection();
			PreparedStatement ps = conn.prepareStatement(sql);

			if (autor != null && autor.getNome() != null) { 
				ps.setString(1, autor.getNome());	
			}
			
			ResultSet rs = ps.executeQuery();
			
			while (rs.next()) {
				Autor at = new Autor();
				at.setId(rs.getLong("AUTOR_ID"));
				at.setNome(rs.getString("NOME"));
				
				col.add(at);
			}
			
			return col;
			
		} catch (Exception e) {
			throw new DAOException(e);
		}
	}

	public Autor pesquisarById(Long autorId) throws DAOException {
		Autor autor = null;
		
		try {
			if (autorId != null) {				

				String sql = "SELECT * FROM AUTOR WHERE AUTOR_ID = ? ";
				
				Connection conn = MyConnection.getConnection();
				PreparedStatement ps = conn.prepareStatement(sql); 
				ps.setLong(1, autorId);
				
				ResultSet rs = ps.executeQuery();		
				
				if (rs.next()) {
					autor = new Autor();
					autor.setId(rs.getLong("AUTOR_ID"));
					autor.setNome(rs.getString("NOME"));
				}
			}
			
			return autor;
			
		} catch (Exception e) {
			throw new DAOException(e);
		}
	}
}
