package br.rj.senac.bibliosoft.model.dao;

import br.rj.senac.bibliosoft.exception.DAOException;
import br.rj.senac.bibliosoft.model.EntityModel;

public interface IBibliosoftDAO {
	
	public void inserir(EntityModel em) throws DAOException;
	public void excluir(EntityModel em) throws DAOException;
	public void alterar(EntityModel em) throws DAOException;
}
