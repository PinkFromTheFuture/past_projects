package br.rj.senac.bibliosoft.model.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Collection;

import br.rj.senac.bibliosoft.exception.DAOException;
import br.rj.senac.bibliosoft.model.Curso;
import br.rj.senac.bibliosoft.model.Usuario;
import br.rj.senac.bibliosoft.model.UsuarioCurso;
import br.rj.senac.bibliosoft.model.conexao.MyConnection;
import br.rj.senac.bibliosoft.model.dao.ICursoDAO;
import br.rj.senac.bibliosoft.model.dao.IUsuarioCursoDAO;
import br.rj.senac.bibliosoft.model.dao.IUsuarioDAO;
import br.rj.senac.bibliosoft.model.dao.factory.DAOFactory;

public class UsuarioCursoJdbcDAO implements IUsuarioCursoDAO {

	private ICursoDAO cursoDAO = DAOFactory.getCursoDAO();
	private IUsuarioDAO usuarioDAO = DAOFactory.getUsuarioDAO();
	
	public void excluir(UsuarioCurso uc) throws DAOException {
		try {	
			if (uc != null) {
				
				String sql = 
						"DELETE FROM USUARIO_CURSO " +
						"WHERE USUARIO_ID = ? " +
						"  AND CURSO_ID = ? ";
				
				Connection conn = MyConnection.getConnection();
				PreparedStatement ps = conn.prepareStatement(sql);

				ps.setLong(1, uc.getUsuario().getId());
				ps.setLong(2, uc.getCurso().getId());
				
				ps.executeUpdate();
				
				ps.close();
			}
			
		} catch (Exception e) {
			throw new DAOException(e);
		}
	}

	public void inserir(UsuarioCurso uc) throws DAOException {
		try {	
			if (uc != null) {
				
				String sql = "INSERT INTO USUARIO_CURSO(USUARIO_ID, CURSO_ID) VALUES (?, ?) ";
				
				Connection conn = MyConnection.getConnection();
				PreparedStatement ps = conn.prepareStatement(sql);

				ps.setLong(1, uc.getUsuario().getId());
				ps.setLong(2, uc.getCurso().getId());
				
				ps.executeUpdate();
				
				ps.close();
			}
			
		} catch (Exception e) {
			throw new DAOException(e);
		}
	}

	public Collection<UsuarioCurso> pesquisarByCurso(Curso c) throws DAOException {
		try {
			
			Collection<UsuarioCurso> col = new ArrayList<UsuarioCurso>();
			if (c != null) {
				
				String sql = "SELECT * FROM USUARIO_CURSO WHERE 1 = 1 ";
				
				if (c.getId() != null) {
					sql += " AND CURSO_ID = ? ";
				}
				
				Connection conn = MyConnection.getConnection();
				PreparedStatement ps = conn.prepareStatement(sql);

				if (c.getId() != null) { 
					ps.setLong(1, c.getId());	
				}
				
				Curso curso = cursoDAO.pesquisarById(c.getId());
				
				ResultSet rs = ps.executeQuery();
				
				while (rs.next()) {
					UsuarioCurso uc = new UsuarioCurso();
					
					uc.setUsuario( usuarioDAO.pesquisarById(rs.getLong("USUARIO_ID")) );
					uc.setCurso(curso);
					
					col.add(uc);
				}
			}
			
			return col;
			
		} catch (Exception e) {
			throw new DAOException(e);
		}
	}

	public Collection<UsuarioCurso> pesquisarByUsuario(Usuario u) throws DAOException {
		try {
			
			Collection<UsuarioCurso> col = new ArrayList<UsuarioCurso>();
			if (u != null) {
				
				String sql = "SELECT * FROM USUARIO_CURSO WHERE 1 = 1 ";
				
				if (u.getId() != null) {
					sql += " AND USUARIO_ID = ? ";
				}
				
				Connection conn = MyConnection.getConnection();
				PreparedStatement ps = conn.prepareStatement(sql);

				if (u.getId() != null) { 
					ps.setLong(1, u.getId());	
				}
				
				Usuario usuario = usuarioDAO.pesquisarById(u.getId());
				
				ResultSet rs = ps.executeQuery();
				
				while (rs.next()) {
					UsuarioCurso uc = new UsuarioCurso();
					
					uc.setUsuario( usuario );
					uc.setCurso( cursoDAO.pesquisarById(rs.getLong("CURSO_ID")) );
					
					col.add(uc);
				}
			}
			
			return col;
			
		} catch (Exception e) {
			throw new DAOException(e);
		}
	}
}
