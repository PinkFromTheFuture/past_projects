package br.rj.senac.bibliosoft.view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Rectangle;
import java.awt.Toolkit;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import javax.swing.JDesktopPane;

import br.rj.senac.bibliosoft.view.cadastroeditora.CadastroEditoraView;

public class TelaPrincipalView extends JFrame {

	
	private static final long serialVersionUID = 1L;
	private JPanel jContentPane = null;
	private JMenuBar jJMenuBar = null;
	private JMenu jMenuCadastro = null;
	private JMenuItem jMenuItemEditora = null;
	private JMenuItem jMenuItemLivro = null;
	private JMenu jMenuEmprestimo = null;
	private JMenu jMenuSobre = null;
	private JMenuItem jMenuItemAjuda = null;
	private JMenuItem jMenuItemSobreAutor = null;
	private JMenuItem jMenuItemReserva = null;
	private JMenuItem jMenuItemEmprestar = null;
	private JMenuItem jMenuItemBibliotecario = null;
	private JMenuItem jMenuItemAutor = null;
	private JMenuItem jMenuItemUsuario = null;
	private JMenuItem jMenuItemCurso = null;
	private JLabel jLabel = null;
	private JLabel jLabel1 = null;
	
	private CadastroEditoraView cEditoraView = null;
	private JDesktopPane jDesktopPane = null;

	/**
	 * This method initializes jJMenuBar	
	 * 	
	 * @return javax.swing.JMenuBar	
	 */
	private JMenuBar getJJMenuBar() {
		if (jJMenuBar == null) {
			jJMenuBar = new JMenuBar();
			jJMenuBar.add(getJMenuCadastro());
			jJMenuBar.add(getJMenuEmprestimo());
			jJMenuBar.add(getJMenuSobre());
		}
		return jJMenuBar;
	}

	/**
	 * This method initializes jMenuCadastro	
	 * 	
	 * @return javax.swing.JMenu	
	 */
	private JMenu getJMenuCadastro() {
		if (jMenuCadastro == null) {
			jMenuCadastro = new JMenu();
			jMenuCadastro.setText("Cadastros");
			jMenuCadastro.add(getJMenuItemEditora());
			jMenuCadastro.add(getJMenuItemLivro());
			jMenuCadastro.add(getJMenuItemBibliotecario());
			jMenuCadastro.add(getJMenuItemAutor());
			jMenuCadastro.add(getJMenuItemUsuario());
			jMenuCadastro.add(getJMenuItemCurso());
		}
		return jMenuCadastro;
	}

	/**
	 * This method initializes jMenuItemEditora	
	 * 	
	 * @return javax.swing.JMenuItem	
	 */
	private JMenuItem getJMenuItemEditora() {
		if (jMenuItemEditora == null) {
			jMenuItemEditora = new JMenuItem();
			jMenuItemEditora.setText("Editora ...");
			jMenuItemEditora.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {

					if (cEditoraView != null) {
						cEditoraView.dispose();
		            } else {
		            	cEditoraView = new CadastroEditoraView();	
		            }
					
					cEditoraView.setMaximizable(false);
					cEditoraView.setClosable(true);
					cEditoraView.setResizable(false);
					cEditoraView.setIconifiable(false);
					cEditoraView.setLocation(0, 0);
					
					jDesktopPane.add(cEditoraView);
					jDesktopPane.setVisible(true);
					
					cEditoraView.setSize(ConstantesView.INTERNAL_FRAME_WIDTH, 
							ConstantesView.INTERNAL_FRAME_HEIGHT);
					cEditoraView.setVisible(true);
					
				}
			});
		}
		return jMenuItemEditora;
	}

	/**
	 * This method initializes jMenuItemLivro	
	 * 	
	 * @return javax.swing.JMenuItem	
	 */
	private JMenuItem getJMenuItemLivro() {
		if (jMenuItemLivro == null) {
			jMenuItemLivro = new JMenuItem();
			jMenuItemLivro.setText("Livro ...");
		}
		return jMenuItemLivro;
	}

	/**
	 * This method initializes jMenuEmprestimo	
	 * 	
	 * @return javax.swing.JMenu	
	 */
	private JMenu getJMenuEmprestimo() {
		if (jMenuEmprestimo == null) {
			jMenuEmprestimo = new JMenu();
			jMenuEmprestimo.setText("Empr�stimos");
			jMenuEmprestimo.add(getJMenuItemReserva());
			jMenuEmprestimo.add(getJMenuItemEmprestar());
		}
		return jMenuEmprestimo;
	}

	/**
	 * This method initializes jMenuSobre	
	 * 	
	 * @return javax.swing.JMenu	
	 */
	private JMenu getJMenuSobre() {
		if (jMenuSobre == null) {
			jMenuSobre = new JMenu();
			jMenuSobre.setText("Sobre");
			jMenuSobre.add(getJMenuItemAjuda());
			jMenuSobre.add(getJMenuItemSobreAutor());
		}
		return jMenuSobre;
	}

	/**
	 * This method initializes jMenuItemAjuda	
	 * 	
	 * @return javax.swing.JMenuItem	
	 */
	private JMenuItem getJMenuItemAjuda() {
		if (jMenuItemAjuda == null) {
			jMenuItemAjuda = new JMenuItem();
			jMenuItemAjuda.setText("Ajuda ...");
		}
		return jMenuItemAjuda;
	}

	/**
	 * This method initializes jMenuItemSobreAutor	
	 * 	
	 * @return javax.swing.JMenuItem	
	 */
	private JMenuItem getJMenuItemSobreAutor() {
		if (jMenuItemSobreAutor == null) {
			jMenuItemSobreAutor = new JMenuItem();
			jMenuItemSobreAutor.setText("Sobre o Autor");
		}
		return jMenuItemSobreAutor;
	}

	/**
	 * This method initializes jMenuItemReserva	
	 * 	
	 * @return javax.swing.JMenuItem	
	 */
	private JMenuItem getJMenuItemReserva() {
		if (jMenuItemReserva == null) {
			jMenuItemReserva = new JMenuItem();
			jMenuItemReserva.setText("Reservar ...");
		}
		return jMenuItemReserva;
	}

	/**
	 * This method initializes jMenuItemEmprestar	
	 * 	
	 * @return javax.swing.JMenuItem	
	 */
	private JMenuItem getJMenuItemEmprestar() {
		if (jMenuItemEmprestar == null) {
			jMenuItemEmprestar = new JMenuItem();
			jMenuItemEmprestar.setText("Emprestar ...");
		}
		return jMenuItemEmprestar;
	}

	/**
	 * This method initializes jMenuItemBibliotecario	
	 * 	
	 * @return javax.swing.JMenuItem	
	 */
	private JMenuItem getJMenuItemBibliotecario() {
		if (jMenuItemBibliotecario == null) {
			jMenuItemBibliotecario = new JMenuItem();
			jMenuItemBibliotecario.setText("Bibliotec�rio ...");
		}
		return jMenuItemBibliotecario;
	}

	/**
	 * This method initializes jMenuItemAutor	
	 * 	
	 * @return javax.swing.JMenuItem	
	 */
	private JMenuItem getJMenuItemAutor() {
		if (jMenuItemAutor == null) {
			jMenuItemAutor = new JMenuItem();
			jMenuItemAutor.setText("Autor ...");
		}
		return jMenuItemAutor;
	}

	/**
	 * This method initializes jMenuItemUsuario	
	 * 	
	 * @return javax.swing.JMenuItem	
	 */
	private JMenuItem getJMenuItemUsuario() {
		if (jMenuItemUsuario == null) {
			jMenuItemUsuario = new JMenuItem();
			jMenuItemUsuario.setText("Usu�rio ...");
		}
		return jMenuItemUsuario;
	}

	/**
	 * This method initializes jMenuItemCurso	
	 * 	
	 * @return javax.swing.JMenuItem	
	 */
	private JMenuItem getJMenuItemCurso() {
		if (jMenuItemCurso == null) {
			jMenuItemCurso = new JMenuItem();
			jMenuItemCurso.setText("Curso ...");
		}
		return jMenuItemCurso;
	}


	/**
	 * This method initializes jDesktopPane	
	 * 	
	 * @return javax.swing.JDesktopPane	
	 */
	private JDesktopPane getJDesktopPane() {
		if (jDesktopPane == null) {
			jDesktopPane = new JDesktopPane();
			jDesktopPane.setLayout(new BorderLayout());
			jDesktopPane.setBounds(new Rectangle(0, 0, 
					ConstantesView.INTERNAL_FRAME_WIDTH, 
					ConstantesView.INTERNAL_FRAME_HEIGHT));
			jDesktopPane.setVisible(false);
			
		}
		return jDesktopPane;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				TelaPrincipalView thisClass = new TelaPrincipalView();
				thisClass.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				thisClass.setVisible(true);
			}
		});
	}

	/**
	 * This is the default constructor
	 */
	public TelaPrincipalView() {
		super();
		initialize();
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		
		Toolkit tk = Toolkit.getDefaultToolkit();
		Dimension screenSize = tk.getScreenSize();
		
		this.setResizable(false);

		this.setSize(ConstantesView.FRAME_WIDTH, ConstantesView.FRAME_HEIGHT);
		this.setJMenuBar(getJJMenuBar());
		
		this.setLocation((screenSize.width -  this.getSize().width) / 2,
                		 (screenSize.height - this.getSize().height) / 2);
		
		this.setContentPane(getJContentPane());
		this.setTitle("Bibliosoft - Sistema de Bibliotecas do SENAC");
	}

	/**
	 * This method initializes jContentPane
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJContentPane() {
		if (jContentPane == null) {
			jLabel1 = new JLabel();
			jLabel1.setBounds(new Rectangle(266, 257, 236, 16));
			jLabel1.setFont(new Font("Dialog", Font.BOLD, 14));
			jLabel1.setText("Sistema de Bibliotecas do SENAC");
			jLabel = new JLabel();
			jLabel.setText("Bibliosoft");
			jLabel.setFont(new Font("Bookman Old Style", Font.BOLD | Font.ITALIC, 36));
			jLabel.setPreferredSize(new Dimension(110, 43));
			jLabel.setName("jLabel");
			jLabel.setBounds(new Rectangle(285, 209, 196, 43));
			jLabel.setBackground(new Color(0, 126, 237));
			jContentPane = new JPanel();
			jContentPane.setLayout(null);
			jContentPane.add(getJDesktopPane(), null);
			jContentPane.add(jLabel, null);
			jContentPane.add(jLabel1, null);
		}
		return jContentPane;
	}

}
