package br.rj.senac.bibliosoft.control;

import java.util.Collection;

import br.rj.senac.bibliosoft.exception.BusinessException;
import br.rj.senac.bibliosoft.exception.DAOException;
import br.rj.senac.bibliosoft.exception.DatabaseException;
import br.rj.senac.bibliosoft.model.Emprestimo;
import br.rj.senac.bibliosoft.model.Exemplar;
import br.rj.senac.bibliosoft.model.conexao.MyConnection;
import br.rj.senac.bibliosoft.model.dao.IEmprestimoDAO;
import br.rj.senac.bibliosoft.model.dao.IExemplarDAO;
import br.rj.senac.bibliosoft.model.dao.factory.DAOFactory;

public class EmprestimoController extends BibliosoftController {

	private static final int QTD_MAXIMA_EMPRESTIMOS_EM_ABERTO = 3;
	
	private IEmprestimoDAO emprestimoDAO = DAOFactory.getEmprestimoDAO();
	private IExemplarDAO exemplarDAO = DAOFactory.getExemplarDAO();
	
	/**
	 * Efetua a reserva de um empr�stimo.
	 * 
	 * @param emprestimo
	 * @throws BusinessException
	 * @throws DatabaseException
	 */
	public void efetuarReserva(Emprestimo emprestimo) throws BusinessException, DatabaseException {
		try {
		
			MyConnection.beginTransaction();
			
			criticarQuantidadeReservas(emprestimo);
			criticarExemplarPorLivro(emprestimo);
			criticarDataEntrega(emprestimo);
			
			Exemplar exemplar = emprestimo.getExemplar();
			exemplar.setDisponivel(Boolean.FALSE);
			
			exemplarDAO.alterar(exemplar);
			
			emprestimoDAO.inserir(emprestimo);
			MyConnection.commit();
			
		} catch (Exception e) {
			super.doRollback(e);
		}
	}

	/**
	 * Efetua a entrega de um empr�stimo.
	 * 
	 * @param emprestimo
	 * @throws BusinessException
	 * @throws DatabaseException
	 */
	public void efetuarEntrega(Emprestimo emprestimo) throws BusinessException, DatabaseException {
		try {
			
			MyConnection.beginTransaction();
			
			criticarEmprestimoJaEntregue(emprestimo);
			
			Exemplar exemplar = emprestimo.getExemplar();
			exemplar.setDisponivel(Boolean.TRUE);
			
			exemplarDAO.alterar(exemplar);
			
			emprestimoDAO.alterar(emprestimo);
			MyConnection.commit();
			
		} catch (Exception e) {
			super.doRollback(e);
		}
	}
	
	/**
	 * Pesquisa um empr�stimo pelo id.
	 * 
	 * @param emprestimo
	 * @throws BusinessException
	 * @throws DatabaseException
	 */
	public Emprestimo pesquisarEmprestimoById(Long id) throws BusinessException, DatabaseException {
		try {
			
			return emprestimoDAO.pesquisarById(id);
			
		} catch (Exception e) {
			super.doRollback(e);
			
			return null;
		}
	}

	/**
	 * REGRA: N�o � poss�vel efetuar um empr�stimo quando a data de entrega 
	 * j� estiver sido preenchida.
	 * 
	 * @param emprestimo
	 * @throws BusinessException
	 */
	private void criticarDataEntrega(Emprestimo emprestimo) throws BusinessException {
		
		if (emprestimo.getDataEntrega() != null) {
			throw new BusinessException("O empr�stimo n�o poder� ser realizado pois o mesmo " +
					"j� possui data de entrega preenchida.");
		}
	}
	
	/**
	 * REGRA: N�o � poss�vel efetuar a entrega de um empr�stimo quando a data de entregue
	 * n�o estiver sido preenchida.
	 * 
	 * @param emprestimo
	 * @throws BusinessException
	 */
	private void criticarEmprestimoJaEntregue(Emprestimo emprestimo) throws BusinessException {
		if (emprestimo.getDataEntrega() == null) {
			throw new BusinessException("A entrega do empr�stimo n�o poder� ser realizada pois o empr�stimo " +
					"n�o possui data de entrega preenchida.");
		}
	}

	/**
	 * REGRA: Um usu�rio n�o pode efetuar mais do que 3 empr�stimos
	 * simultaneamente.
	 * 
	 * @param emprestimo
	 * @throws BusinessException
	 * @throws DAOException
	 */
	private void criticarQuantidadeReservas(Emprestimo emprestimo) throws BusinessException, DAOException {
		
		Collection<Emprestimo> emprestimosEmAberto = emprestimoDAO.pesquisarByUsuario(
				emprestimo.getUsuario(), Boolean.TRUE);
		
		if (emprestimosEmAberto != null && emprestimosEmAberto.size() >= QTD_MAXIMA_EMPRESTIMOS_EM_ABERTO) {
			
			throw new BusinessException("O usu�rio '" + emprestimo.getUsuario().getNome() + 
					"' j� possui " + QTD_MAXIMA_EMPRESTIMOS_EM_ABERTO + " empr�stimos em aberto. " +
					"N�o � poss�vel efetuar mais reservas at� que pelo menos uma seja entregue.");
		}
	}
	
	/**
	 * REGRA: Um usu�rio n�o poder� efetuar mais de uma reserva de um exemplar 
	 * de um mesmo livro simultaneamente.
	 * 
	 * @param emprestimo
	 * @throws BusinessException
	 * @throws DAOException
	 */
	private void criticarExemplarPorLivro(Emprestimo emprestimo) throws BusinessException, DAOException {
		
		Collection<Emprestimo> emprestimosEmAberto = emprestimoDAO.pesquisarByUsuario(
				emprestimo.getUsuario(), Boolean.TRUE);
		
		if (emprestimosEmAberto != null) {
			
			//FOR_ITERATE: Dispon�vel a partir do Java 5.0
			for (Emprestimo empr : emprestimosEmAberto) {
				if (empr.getExemplar().getLivro().getId().equals(
						emprestimo.getExemplar().getLivro().getId())) {
					
					throw new BusinessException("O usu�rio '" + emprestimo.getUsuario().getNome() + 
							"' j� possui j� possui um exemplar do livro '" +
							empr.getExemplar().getLivro().getNome() + "' em aberto. " +
							"N�o � poss�vel efetuar esta reserva at� que o outro exemplar seja entregue.");
				}
			}
		}
	}
}
