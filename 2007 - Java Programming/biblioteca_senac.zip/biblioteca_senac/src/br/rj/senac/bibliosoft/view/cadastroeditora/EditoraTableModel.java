package br.rj.senac.bibliosoft.view.cadastroeditora;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.swing.table.AbstractTableModel;

import br.rj.senac.bibliosoft.model.Editora;

public class EditoraTableModel extends AbstractTableModel {

	private String[] colunas = new String[] {"id", "Nome"};
	private List<Editora> linhas = new ArrayList<Editora>();
	private boolean[] colsEdicao = {false, false};
	
	public EditoraTableModel() {
	}
	
	public List<Editora> getLinhas() {
		return linhas;
	}

	public void setLinhas(List<Editora> linhas) {
		for (Editora editora : linhas) {
			this.addRow(editora);
		}
	}

	public String[] getColunas() {
		return colunas;
	}

	public void setColunas(String[] colunas) {
		this.colunas = colunas;
	}

	public int getColumnCount() {
		return getColunas().length;
	}

	public int getRowCount() {
		return getLinhas().size();
	}

	public Object getValueAt(int rowIndex, int colIndex) {
		Editora linha = getLinhas().get(rowIndex);
		
		switch (colIndex) {
		case 0 : 
			return linha.getId();
			
		case 1 :
			return linha.getNome();
			
		default :
			return linha.getNome();
		}
	}
	
	public void setValueAt(Editora editora, int row) {
		this.getLinhas().set(row, editora);
		
		for (int  i = 0; i < colunas.length; i++) {
			fireTableCellUpdated(row, i);	
		}
	}
	
	public boolean isCellEditable(int row, int col) {
		return colsEdicao[col];
	}
	
	public void addRow(Editora dadosLinha) {
		
		getLinhas().add(dadosLinha);
		
		int linha = getLinhas().size() - 1;
		
		fireTableRowsInserted(linha, linha);
	}
	
	public void removeRow(int row) {
		getLinhas().remove(0);
		
		fireTableRowsDeleted(row, row);
	}
	
	public boolean removeRow(Editora val, int col) {
		int linha = 0;
		
		for (Iterator<Editora> it = getLinhas().iterator(); it.hasNext();) {
			Editora linhaCorrente = it.next();
			linha++;
			
			if (linhaCorrente.equals(val)) {
				getLinhas().remove(linha);
				
				fireTableRowsDeleted(linha, linha);
				
				return true;
			}
		}
		
		return false;
	}
	
	public String getColumnName(int col) {
		return getColunas()[col];
	}
}
