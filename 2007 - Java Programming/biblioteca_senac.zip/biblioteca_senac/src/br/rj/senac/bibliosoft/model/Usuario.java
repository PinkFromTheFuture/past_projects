package br.rj.senac.bibliosoft.model;

public class Usuario extends EntityModel {

	private Long id;
	private String nome;
	private String matricula;
	
	public Usuario() {
		
	}
	
	public Long getId() {
		return id;
	}
	
	public void setId(Long usuarioId) {
		this.id = usuarioId;
	}
	
	public String getNome() {
		return nome;
	}
	
	public void setNome(String nome) {
		this.nome = nome;
	}
	
	public String getMatricula() {
		return matricula;
	}
	
	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}
}
