package br.rj.senac.bibliosoft.model;

public class Editora extends EntityModel {
	
	private Long id;
	private String nome;
	
	public Editora() {
		
	}
	
	public Long getId() {
		return id;
	}
	
	public void setId(Long editoraId) {
		this.id = editoraId;
	}
	
	public String getNome() {
		return nome;
	}
	
	public void setNome(String nome) {
		this.nome = nome;
	}
	
	
	public boolean equals(Object obj) {
		
		if (obj == null) {
			return false;
		}
		
		if (!(obj instanceof Editora)) {
			return false;
		}
		
		Editora ed = (Editora)obj;
		
		if (this.getNome() != null && !this.getNome().equals(ed.getNome())) {
			return false;
		}
		
		return true;
	}
}
