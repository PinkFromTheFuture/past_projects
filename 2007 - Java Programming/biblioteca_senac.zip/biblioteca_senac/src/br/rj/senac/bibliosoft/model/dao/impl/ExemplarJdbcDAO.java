package br.rj.senac.bibliosoft.model.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import br.rj.senac.bibliosoft.exception.DAOException;
import br.rj.senac.bibliosoft.model.EntityModel;
import br.rj.senac.bibliosoft.model.Exemplar;
import br.rj.senac.bibliosoft.model.conexao.MyConnection;
import br.rj.senac.bibliosoft.model.dao.IExemplarDAO;
import br.rj.senac.bibliosoft.model.dao.ILivroDAO;
import br.rj.senac.bibliosoft.model.dao.factory.DAOFactory;

public class ExemplarJdbcDAO implements IExemplarDAO {

	private ILivroDAO livroDAO = DAOFactory.getLivroDAO();
	
	public void alterar(EntityModel em) throws DAOException {
		try {
			if (em != null) {
				
				Exemplar exemplar = (Exemplar)em;
				
				String sql = "UPDATE EXEMPLAR SET CODIGO = ?, DISPONIVEL = ?, LIVRO_ID = ? " +
						"WHERE EXEMPLAR_ID = ? ";
				
				Connection conn = MyConnection.getConnection();
				PreparedStatement ps = conn.prepareStatement(sql);
				
				ps.setString(1, exemplar.getCodigo());
				ps.setBoolean(2, exemplar.getDisponivel());
				ps.setLong(3, exemplar.getLivro().getId());
				ps.setLong(4, exemplar.getId());
				
				ps.executeUpdate();
				
				ps.close();
			}
			
		} catch (Exception e) {
			throw new DAOException(e);
		}
	}

	public void excluir(EntityModel em) throws DAOException {
		try {	
			if (em != null) {
				
				Exemplar exemplar = (Exemplar)em;
				
				String sql = "DELETE FROM EXEMPLAR WHERE EXEMPLAR_ID = ? ";
				
				Connection conn = MyConnection.getConnection();
				PreparedStatement ps = conn.prepareStatement(sql);

				ps.setLong(1, exemplar.getId());
				
				ps.executeUpdate();
				
				ps.close();
			}
			
		} catch (Exception e) {
			throw new DAOException(e);
		}

	}

	public void inserir(EntityModel em) throws DAOException {
		try {	
			if (em != null) {
				
				Exemplar exemplar = (Exemplar)em;
				
				String sql = "INSERT INTO EXEMPLAR(CODIGO, DISPONIVEL, LIVRO_ID) VALUES (?, ?, ?) ";
				
				Connection conn = MyConnection.getConnection();
				PreparedStatement ps = conn.prepareStatement(sql);

				ps.setString(1, exemplar.getCodigo());
				ps.setBoolean(2, exemplar.getDisponivel());
				ps.setLong(3, exemplar.getLivro().getId());
				
				ps.executeUpdate();
				
				ps.close();
			}
			
		} catch (Exception e) {
			throw new DAOException(e);
		}
	}

	public List<Exemplar> pesquisar(Exemplar exemplar) throws DAOException {
		try {
			
			List<Exemplar> col = new ArrayList<Exemplar>();
				
			String sql = "SELECT * FROM EXEMPLAR WHERE 1 = 1 ";
			
			if (exemplar != null && exemplar.getCodigo() != null) {
				sql += " AND CODIGO LIKE ? ";
			}
			
			if (exemplar != null && exemplar.getDisponivel() != null) {
				sql += " AND DISPONIVEL = ? ";
			}
			
			if (exemplar != null && exemplar.getLivro() != null && exemplar.getLivro().getId() != null) {
				sql += " AND LIVRO_ID = ? ";
			}
			
			Connection conn = MyConnection.getConnection();
			PreparedStatement ps = conn.prepareStatement(sql);

			int posicao = 1;
			if (exemplar != null && exemplar.getCodigo() != null) { 
				ps.setString(posicao, exemplar.getCodigo());
				posicao++;
			}
			
			if (exemplar != null && exemplar.getDisponivel() != null) {
				ps.setBoolean(posicao, exemplar.getDisponivel());
				posicao++;
			}
			
			if (exemplar != null && exemplar.getLivro() != null && exemplar.getLivro().getId() != null) {
				ps.setLong(posicao, exemplar.getLivro().getId());
				posicao++;
			}
			
			ResultSet rs = ps.executeQuery();
			
			while (rs.next()) {
				Exemplar ex = new Exemplar();
				ex.setId(rs.getLong("EXEMPLAR_ID"));
				ex.setCodigo(rs.getString("CODIGO"));
				ex.setDisponivel(rs.getBoolean("DISPONIVEL"));
				ex.setLivro( livroDAO.pesquisarById(rs.getLong("LIVRO_ID")) );
				
				col.add(ex);
			}
			
			return col;
			
		} catch (Exception e) {
			throw new DAOException(e);
		}
	}
	
	public Exemplar pesquisarById(Long exemplarId) throws DAOException {
		Exemplar exemplar = null;
		
		try {
			if (exemplarId != null) {				

				String sql = "SELECT * FROM EXEMPLAR WHERE EXEMPLAR_ID = ? ";
				
				Connection conn = MyConnection.getConnection();
				PreparedStatement ps = conn.prepareStatement(sql); 
				ps.setLong(1, exemplarId);
				
				ResultSet rs = ps.executeQuery();		
				
				if (rs.next()) {
					exemplar = new Exemplar();
					exemplar.setId(rs.getLong("EXEMPLAR_ID"));
					exemplar.setCodigo(rs.getString("CODIGO"));
					exemplar.setDisponivel(rs.getBoolean("DISPONIVEL"));
					exemplar.setLivro( livroDAO.pesquisarById(rs.getLong("LIVRO_ID")) );
				}
			}
			
			return exemplar;
			
		} catch (Exception e) {
			throw new DAOException(e);
		}
	}
}
