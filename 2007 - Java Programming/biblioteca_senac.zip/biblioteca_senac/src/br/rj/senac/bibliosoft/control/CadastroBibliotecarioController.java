package br.rj.senac.bibliosoft.control;

import java.util.List;

import br.rj.senac.bibliosoft.exception.BusinessException;
import br.rj.senac.bibliosoft.exception.DatabaseException;
import br.rj.senac.bibliosoft.model.Bibliotecario;
import br.rj.senac.bibliosoft.model.conexao.MyConnection;
import br.rj.senac.bibliosoft.model.dao.IBibliotecarioDAO;
import br.rj.senac.bibliosoft.model.dao.factory.DAOFactory;

public class CadastroBibliotecarioController extends BibliosoftController {

	private IBibliotecarioDAO bibliotecarioDAO = DAOFactory.getBibliotecarioDAO();
	
	public CadastroBibliotecarioController() {
		
	}
	
	public void inserirBibliotecario(Bibliotecario bibliotecario) throws BusinessException, DatabaseException {
		try {
			
			MyConnection.beginTransaction();
			bibliotecarioDAO.inserir(bibliotecario);
			MyConnection.commit();
			
		} catch (Exception e) {
			super.doRollback(e);
		}
	}
	
	public void excluirBibliotecario(Bibliotecario bibliotecario) throws BusinessException, DatabaseException {
		try {
			
			MyConnection.beginTransaction();
			bibliotecarioDAO.excluir(bibliotecario);
			MyConnection.commit();
			
		} catch (Exception e) {
			
			super.doRollback(e);
		}
	}
	
	public void alterarBibliotecario(Bibliotecario bibliotecario) throws BusinessException, DatabaseException {
		try {
			
			MyConnection.beginTransaction();
			bibliotecarioDAO.alterar(bibliotecario);
			MyConnection.commit();
			
		} catch (Exception e) {
			
			super.doRollback(e);
		}
	}
	
	public List<Bibliotecario> pesquisarBibliotecario(Bibliotecario bibliotecario) throws BusinessException, DatabaseException {
		try {
			
			return bibliotecarioDAO.pesquisar(bibliotecario);
			
		} catch (Exception e) {
			
			super.doRollback(e);
			
			return null;
		}
	}
	
	public Bibliotecario pesquisarBibliotecarioById(Long id) throws BusinessException, DatabaseException {
		try {
			
			return bibliotecarioDAO.pesquisarById(id);
			
		} catch (Exception e) {
			
			super.doRollback(e);
			
			return null;
		}
	}
}
