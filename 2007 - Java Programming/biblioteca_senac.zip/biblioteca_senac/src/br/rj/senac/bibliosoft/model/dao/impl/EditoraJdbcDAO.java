package br.rj.senac.bibliosoft.model.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import br.rj.senac.bibliosoft.exception.DAOException;
import br.rj.senac.bibliosoft.model.Editora;
import br.rj.senac.bibliosoft.model.EntityModel;
import br.rj.senac.bibliosoft.model.conexao.MyConnection;
import br.rj.senac.bibliosoft.model.dao.IEditoraDAO;

public class EditoraJdbcDAO implements IEditoraDAO {

	public void alterar(EntityModel em) throws DAOException {
		try {	
			if (em != null) {
				
				Editora editora = (Editora)em;
				
				String sql = "UPDATE EDITORA SET NOME = ? WHERE EDITORA_ID = ? ";
				
				Connection conn = MyConnection.getConnection();
				PreparedStatement ps = conn.prepareStatement(sql);
				
				ps.setString(1, editora.getNome());
				ps.setLong(2, editora.getId());
				
				ps.executeUpdate();
				
				ps.close();
			}
			
		} catch (Exception e) {
			throw new DAOException(e);
		}
	}

	public void excluir(EntityModel em) throws DAOException {
		try {	
			if (em != null) {
				
				Editora editora = (Editora)em;
				
				String sql = "DELETE FROM EDITORA WHERE EDITORA_ID = ? ";
				
				Connection conn = MyConnection.getConnection();
				PreparedStatement ps = conn.prepareStatement(sql);

				ps.setLong(1, editora.getId());
				
				ps.executeUpdate();
				
				ps.close();
			}
			
		} catch (Exception e) {
			throw new DAOException(e);
		}
	}

	public void inserir(EntityModel em) throws DAOException {
		try {	
			if (em != null) {
				
				Editora editora = (Editora)em;
				
				String sql = "INSERT INTO EDITORA(NOME) VALUES (?) ";
				
				Connection conn = MyConnection.getConnection();
				PreparedStatement ps = conn.prepareStatement(sql);

				ps.setString(1, editora.getNome());
				
				ps.executeUpdate();
				
				ps.close();
			}
			
		} catch (Exception e) {
			throw new DAOException(e);
		}
	}

	public List<Editora> pesquisar(Editora editora) throws DAOException {
		try {
			
			List<Editora> col = new ArrayList<Editora>();
				
			String sql = "SELECT * FROM EDITORA WHERE 1 = 1 ";
				
			if (editora != null && editora.getNome() != null) {
				sql += " AND NOME LIKE ? ";
			}
				
			Connection conn = MyConnection.getConnection();
			PreparedStatement ps = conn.prepareStatement(sql);

			if (editora != null && editora.getNome() != null) { 
				ps.setString(1, editora.getNome());	
			}
				
			ResultSet rs = ps.executeQuery();
				
			while (rs.next()) {
				Editora ed = new Editora();
				ed.setId(rs.getLong("EDITORA_ID"));
				ed.setNome(rs.getString("NOME"));
					
				col.add(ed);
			}
			
			return col;
			
		} catch (Exception e) {
			throw new DAOException(e);
		}
	}

	public Editora pesquisarById(Long editoraId) throws DAOException {
		Editora editora = null;
		
		try {
			if (editoraId != null) {

				String sql = "SELECT * FROM EDITORA WHERE EDITORA_ID = ? ";
				
				Connection conn = MyConnection.getConnection();
				PreparedStatement ps = conn.prepareStatement(sql); 
				ps.setLong(1, editoraId);
				
				ResultSet rs = ps.executeQuery();		
				
				if (rs.next()) {
					editora = new Editora();
					editora.setId(rs.getLong("EDITORA_ID"));
					editora.setNome(rs.getString("NOME"));
				}
			}
			
			return editora;
			
		} catch (Exception e) {
			throw new DAOException(e);
		}
	}
}
