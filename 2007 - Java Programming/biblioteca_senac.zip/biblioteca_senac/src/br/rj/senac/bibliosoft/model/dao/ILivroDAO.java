package br.rj.senac.bibliosoft.model.dao;

import java.util.List;

import br.rj.senac.bibliosoft.exception.DAOException;
import br.rj.senac.bibliosoft.model.Livro;

public interface ILivroDAO extends IBibliosoftDAO {
	public Livro pesquisarById(Long livroId) throws DAOException;
	public List<Livro> pesquisar(Livro livro) throws DAOException;
}
