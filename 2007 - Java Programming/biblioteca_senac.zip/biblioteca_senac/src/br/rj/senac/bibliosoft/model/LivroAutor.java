package br.rj.senac.bibliosoft.model;

public class LivroAutor extends EntityModel {

	private Livro livro;
	private Autor autor;
	
	public LivroAutor() {
		
	}
	
	public Livro getLivro() {
		return livro;
	}
	
	public void setLivro(Livro livro) {
		this.livro = livro;
	}
	
	public Autor getAutor() {
		return autor;
	}
	
	public void setAutor(Autor autor) {
		this.autor = autor;
	}
}
