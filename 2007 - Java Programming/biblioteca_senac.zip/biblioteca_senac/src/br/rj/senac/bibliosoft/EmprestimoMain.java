package br.rj.senac.bibliosoft;

import java.util.Date;

import br.rj.senac.bibliosoft.control.CadastroBibliotecarioController;
import br.rj.senac.bibliosoft.control.CadastroExemplarController;
import br.rj.senac.bibliosoft.control.CadastroUsuarioController;
import br.rj.senac.bibliosoft.control.EmprestimoController;
import br.rj.senac.bibliosoft.exception.BusinessException;
import br.rj.senac.bibliosoft.exception.DatabaseException;
import br.rj.senac.bibliosoft.model.Bibliotecario;
import br.rj.senac.bibliosoft.model.Emprestimo;
import br.rj.senac.bibliosoft.model.Exemplar;
import br.rj.senac.bibliosoft.model.Usuario;

public class EmprestimoMain {

	private static EmprestimoController emprestimoController = new EmprestimoController();
	private static CadastroBibliotecarioController bibliotecarioController = new CadastroBibliotecarioController();
	private static CadastroUsuarioController usuarioController = new CadastroUsuarioController();
	private static CadastroExemplarController exemplarController = new CadastroExemplarController();
	
	public static void main(String[] args) {
		
		efetuarReserva();
		efetuarEntrega();
	}
	
	private static void efetuarReserva() {
		
		try {
			
			Emprestimo emprestimo = new Emprestimo();
			
			//Buscando um bibliotecario pelo Id
			Bibliotecario bibliotecario = bibliotecarioController.pesquisarBibliotecarioById(new Long(1));
			
			//Buscando um usuario pelo Id
			Usuario usuario = usuarioController.pesquisarUsuarioById(new Long(1));
			
			//Buscando um exemplar pelo Id
			Exemplar exemplar = exemplarController.pesquisarExemplarById(new Long(1));
			
			emprestimo.setBibliotecario(bibliotecario);
			emprestimo.setUsuario(usuario);
			emprestimo.setExemplar(exemplar);
			
			//efetuando a reserva com a data de hoje
			emprestimo.setDataReserva(new Date());
			emprestimo.setDataEntrega(null);
			
			emprestimoController.efetuarReserva(emprestimo);
			
		} catch (BusinessException e) {
			e.printStackTrace();
		} catch (DatabaseException e) {
			e.printStackTrace();
		}
	}
	
	private static void efetuarEntrega() {
		
		try {
			
			//Pesquisando um emprestimo pelo Id
			Emprestimo emprestimo = emprestimoController.pesquisarEmprestimoById(new Long(1));
			
			//efetuando a entrega com a data de hoje
			emprestimo.setDataEntrega(new Date());
			
			emprestimoController.efetuarEntrega(emprestimo);
			
		} catch (BusinessException e) {
			e.printStackTrace();
		} catch (DatabaseException e) {
			e.printStackTrace();
		}
	}
}
