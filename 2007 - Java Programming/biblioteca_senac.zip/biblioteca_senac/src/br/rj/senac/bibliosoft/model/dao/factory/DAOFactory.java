package br.rj.senac.bibliosoft.model.dao.factory;

import br.rj.senac.bibliosoft.model.dao.IAutorDAO;
import br.rj.senac.bibliosoft.model.dao.IBibliotecarioDAO;
import br.rj.senac.bibliosoft.model.dao.ICursoDAO;
import br.rj.senac.bibliosoft.model.dao.IEditoraDAO;
import br.rj.senac.bibliosoft.model.dao.IEmprestimoDAO;
import br.rj.senac.bibliosoft.model.dao.IExemplarDAO;
import br.rj.senac.bibliosoft.model.dao.ILivroDAO;
import br.rj.senac.bibliosoft.model.dao.IUsuarioDAO;
import br.rj.senac.bibliosoft.model.dao.impl.AutorJdbcDAO;
import br.rj.senac.bibliosoft.model.dao.impl.BibliotecarioJdbcDAO;
import br.rj.senac.bibliosoft.model.dao.impl.CursoJdbcDAO;
import br.rj.senac.bibliosoft.model.dao.impl.EditoraJdbcDAO;
import br.rj.senac.bibliosoft.model.dao.impl.EmprestimoJdbcDAO;
import br.rj.senac.bibliosoft.model.dao.impl.ExemplarJdbcDAO;
import br.rj.senac.bibliosoft.model.dao.impl.LivroJdbcDAO;
import br.rj.senac.bibliosoft.model.dao.impl.UsuarioJdbcDAO;

/**
 * 
 * Fornece as inst�ncias das classes DAO atrav�s das interfaces DAO.
 * 
 * Ajuda a facilitar a migra��o do mecanismo de persist�ncia adotado pela aplica��o,
 * pois para modificar o mecanismo de persist�ncia, basta modificar a constante
 * PERSISTENCE_TYPE e criar as implementa��es espec�ficas do novo mecanismo de 
 * persist�ncia.
 * 
 * As classes Controller nunca devem importar diretamente as implementa��es dos 
 * DAOs, e sim conhecer apenas as interfaces DAO.
 *
 */
public class DAOFactory {

	private static final int JDBC_TYPE = 0;
	private static final int HIBERNATE_TYPE = 1;
	
	private static final int PERSISTENCE_TYPE = JDBC_TYPE;
	
	private static IEditoraDAO editoraDAO;
	private static ICursoDAO cursoDAO;
	private static IUsuarioDAO usuarioDAO;
	private static ILivroDAO livroDAO;
	private static IAutorDAO autorDAO;
	private static IExemplarDAO exemplarDAO;
	private static IBibliotecarioDAO bibliotecarioDAO;
	private static IEmprestimoDAO emprestimoDAO;
	
	public static IEditoraDAO getEditoraDAO() {
		if (editoraDAO == null) {
			if (PERSISTENCE_TYPE == JDBC_TYPE) {
				editoraDAO = new EditoraJdbcDAO();
			}
		}
		
		return editoraDAO;
	}
	
	public static ICursoDAO getCursoDAO() {
		if (cursoDAO == null) {
			if (PERSISTENCE_TYPE == JDBC_TYPE) {
				cursoDAO = new CursoJdbcDAO();
			}
		}
		
		return cursoDAO;
	}
	
	public static IUsuarioDAO getUsuarioDAO() {
		if (usuarioDAO == null) {
			if (PERSISTENCE_TYPE == JDBC_TYPE) {
				usuarioDAO = new UsuarioJdbcDAO();
			}
		}
		
		return usuarioDAO;
	}
	
	public static ILivroDAO getLivroDAO() {
		if (livroDAO == null) {
			if (PERSISTENCE_TYPE == JDBC_TYPE) {
				livroDAO = new LivroJdbcDAO();
			}
		}
		
		return livroDAO;
	}
	
	public static IAutorDAO getAutorDAO() {
		if (autorDAO == null) {
			if (PERSISTENCE_TYPE == JDBC_TYPE) {
				autorDAO = new AutorJdbcDAO();
			}
		}
		
		return autorDAO;
	}
	
	public static IExemplarDAO getExemplarDAO() {
		if (exemplarDAO == null) {
			if (PERSISTENCE_TYPE == JDBC_TYPE) {
				exemplarDAO = new ExemplarJdbcDAO();
			}
		}
		
		return exemplarDAO;
	}
	
	public static IBibliotecarioDAO getBibliotecarioDAO() {
		if (bibliotecarioDAO == null) {
			if (PERSISTENCE_TYPE == JDBC_TYPE) {
				bibliotecarioDAO = new BibliotecarioJdbcDAO();
			}
		}
		
		return bibliotecarioDAO;
	}
	
	public static IEmprestimoDAO getEmprestimoDAO() {
		if (emprestimoDAO == null) {
			if (PERSISTENCE_TYPE == JDBC_TYPE) {
				emprestimoDAO = new EmprestimoJdbcDAO();
			}
		}
		
		return emprestimoDAO;
	}
}
