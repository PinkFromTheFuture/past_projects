package br.rj.senac.bibliosoft.model;

public class Exemplar extends EntityModel {

	private Long id;
	private String codigo;
	private Boolean disponivel;
	private Livro livro;
	
	public Exemplar() {
		
	}
	
	public Long getId() {
		return id;
	}
	
	public void setId(Long exemplarId) {
		this.id = exemplarId;
	}
	
	public String getCodigo() {
		return codigo;
	}
	
	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}
	
	public Boolean getDisponivel() {
		return disponivel;
	}
	
	public void setDisponivel(Boolean disponivel) {
		this.disponivel = disponivel;
	}
	
	public Livro getLivro() {
		return livro;
	}
	
	public void setLivro(Livro livro) {
		this.livro = livro;
	}
}
