package br.rj.senac.bibliosoft.model.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

import br.rj.senac.bibliosoft.exception.DAOException;
import br.rj.senac.bibliosoft.model.Emprestimo;
import br.rj.senac.bibliosoft.model.EntityModel;
import br.rj.senac.bibliosoft.model.Usuario;
import br.rj.senac.bibliosoft.model.conexao.MyConnection;
import br.rj.senac.bibliosoft.model.dao.IBibliotecarioDAO;
import br.rj.senac.bibliosoft.model.dao.IEmprestimoDAO;
import br.rj.senac.bibliosoft.model.dao.IExemplarDAO;
import br.rj.senac.bibliosoft.model.dao.IUsuarioDAO;
import br.rj.senac.bibliosoft.model.dao.factory.DAOFactory;

public class EmprestimoJdbcDAO implements IEmprestimoDAO {

	private IUsuarioDAO usuarioDAO = DAOFactory.getUsuarioDAO();
	private IExemplarDAO exemplarDAO = DAOFactory.getExemplarDAO();
	private IBibliotecarioDAO bibliotecarioDAO = DAOFactory.getBibliotecarioDAO();
	
	public void alterar(EntityModel em) throws DAOException {
		try {
			if (em != null) {
				
				Emprestimo emprestimo = (Emprestimo)em;
				
				String sql = "UPDATE EMPRESTIMO SET DATA_RESERVA = ?, DATA_ENTREGA = ?, " +
						"USUARIO_ID = ?, EXEMPLAR_ID = ?, BIBLIOTECARIO_ID = ? " +
						"WHERE EMPRESTIMO_ID = ? ";
				
				Connection conn = MyConnection.getConnection();
				PreparedStatement ps = conn.prepareStatement(sql);
				
				ps.setDate(1, new java.sql.Date(emprestimo.getDataReserva().getTime()) );
				ps.setDate(2, new java.sql.Date(emprestimo.getDataEntrega().getTime()) );
				ps.setLong(3, emprestimo.getUsuario().getId());
				ps.setLong(4, emprestimo.getExemplar().getId());
				ps.setLong(5, emprestimo.getBibliotecario().getId());
				ps.setLong(6, emprestimo.getId());
				
				ps.executeUpdate();
				
				ps.close();
			}
			
		} catch (Exception e) {
			throw new DAOException(e);
		}
	}

	public void excluir(EntityModel em) throws DAOException {
		try {	
			if (em != null) {
				
				Emprestimo emprestimo = (Emprestimo)em;
				
				String sql = "DELETE FROM EMPRESTIMO WHERE EMPRESTIMO_ID = ? ";
				
				Connection conn = MyConnection.getConnection();
				PreparedStatement ps = conn.prepareStatement(sql);

				ps.setLong(1, emprestimo.getId());
				
				ps.executeUpdate();
				
				ps.close();
			}
			
		} catch (Exception e) {
			throw new DAOException(e);
		}
	}

	public void inserir(EntityModel em) throws DAOException {
		try {	
			if (em != null) {
				
				Emprestimo emprestimo = (Emprestimo)em;
				
				String sql = "INSERT INTO EMPRESTIMO(DATA_RESERVA, DATA_ENTREGA, " +
						"USUARIO_ID, EXEMPLAR_ID, BIBLIOTECARIO_ID) VALUES (?, ?, ?, ?, ?) ";
				
				Connection conn = MyConnection.getConnection();
				PreparedStatement ps = conn.prepareStatement(sql);

				ps.setDate(1, new java.sql.Date(emprestimo.getDataReserva().getTime()) );
				
				if ( emprestimo.getDataEntrega() != null ) {
					ps.setDate(2, new java.sql.Date(emprestimo.getDataEntrega().getTime()) );
					
				} else {
					ps.setNull(2, Types.DATE);
				}
				
				ps.setLong(3, emprestimo.getUsuario().getId());
				ps.setLong(4, emprestimo.getExemplar().getId());
				ps.setLong(5, emprestimo.getBibliotecario().getId());
				
				ps.executeUpdate();
				
				ps.close();
			}
			
		} catch (Exception e) {
			throw new DAOException(e);
		}
	}

	public List<Emprestimo> pesquisar(Emprestimo emprestimo)
			throws DAOException {
		try {
			
			List<Emprestimo> col = new ArrayList<Emprestimo>();
				
			String sql = "SELECT * FROM EMPRESTIMO WHERE 1 = 1 ";
			
			if (emprestimo != null) {
				
				if (emprestimo.getDataReserva() != null) {
					sql += " AND DATA_RESERVA = ? ";
				}
				
				if (emprestimo.getDataEntrega() != null) {
					sql += " AND DATA_ENTREGA = ? ";
				}
				
				if (emprestimo.getUsuario() != null && emprestimo.getUsuario().getId() != null) {
					sql += " AND USUARIO_ID = ? ";
				}
				
				if (emprestimo.getExemplar() != null && emprestimo.getExemplar().getId() != null) {
					sql += " AND EXEMPLAR_ID = ? ";
				}
				
				if (emprestimo.getBibliotecario() != null && emprestimo.getBibliotecario().getId() != null) {
					sql += " AND BIBLIOTECARIO_ID = ? ";
				}	
			}
			
			Connection conn = MyConnection.getConnection();
			PreparedStatement ps = conn.prepareStatement(sql);

			int posicao = 1;
			
			if (emprestimo != null) {
				
				if (emprestimo.getDataReserva() != null) { 
					ps.setDate(posicao, new java.sql.Date(emprestimo.getDataReserva().getTime()) );
					posicao++;
				}
				
				if (emprestimo.getDataEntrega() != null) { 
					ps.setDate(posicao, new java.sql.Date(emprestimo.getDataEntrega().getTime()) );
					posicao++;
				}
				
				if (emprestimo.getUsuario() != null && emprestimo.getUsuario().getId() != null) { 
					ps.setDate(posicao, new java.sql.Date(emprestimo.getDataEntrega().getTime()) );
					posicao++;
				}
				
				if (emprestimo.getExemplar() != null && emprestimo.getExemplar().getId() != null) { 
					ps.setDate(posicao, new java.sql.Date(emprestimo.getDataEntrega().getTime()) );
					posicao++;
				}
				
				if (emprestimo.getBibliotecario() != null && emprestimo.getBibliotecario().getId() != null) { 
					ps.setDate(posicao, new java.sql.Date(emprestimo.getDataEntrega().getTime()) );
					posicao++;
				}	
			}

			ResultSet rs = ps.executeQuery();
			
			while (rs.next()) {
				Emprestimo emp = fillEmprestimo(rs);
				
				col.add(emp);
			}
			
			return col;
			
		} catch (Exception e) {
			throw new DAOException(e);
		}
	}
	
	public List<Emprestimo> pesquisarByUsuario(Usuario usuario,
			Boolean emAberto) throws DAOException {
		try {
			
			List<Emprestimo> col = new ArrayList<Emprestimo>();
			String sql = "SELECT * FROM EMPRESTIMO WHERE 1 = 1 ";
			
			if (usuario != null && usuario.getId() != null) {
				sql += " AND USUARIO_ID = ? ";
			}
				
			if (emAberto != null && emAberto) {
				sql += " AND DATA_ENTREGA IS NULL ";
			}
							
			Connection conn = MyConnection.getConnection();
			PreparedStatement ps = conn.prepareStatement(sql);

			if (usuario != null && usuario.getId() != null) { 
				ps.setLong(1, usuario.getId() );
			}
			
			ResultSet rs = ps.executeQuery();
			
			while (rs.next()) {
				Emprestimo emp = fillEmprestimo(rs);
				
				col.add(emp);
			}
			
			return col;
			
		} catch (Exception e) {
			throw new DAOException(e);
		}
	}
	
	public Emprestimo pesquisarById(Long emprestimoId) throws DAOException {
		Emprestimo emprestimo = null;
		
		try {
			if (emprestimoId != null) {

				String sql = "SELECT * FROM EMPRESTIMO WHERE EMPRESTIMO_ID = ? ";
				
				Connection conn = MyConnection.getConnection();
				PreparedStatement ps = conn.prepareStatement(sql); 
				ps.setLong(1, emprestimoId);
				
				ResultSet rs = ps.executeQuery();		
				
				if (rs.next()) {
					emprestimo = fillEmprestimo(rs);
				}
			}
			
			return emprestimo;
			
		} catch (Exception e) {
			throw new DAOException(e);
		}
	}
	
	private Emprestimo fillEmprestimo(ResultSet rs) throws SQLException, DAOException {
		Emprestimo emp = new Emprestimo();
		emp.setId(rs.getLong("EMPRESTIMO_ID"));
		emp.setDataReserva(rs.getDate("DATA_RESERVA"));
		emp.setDataEntrega(rs.getDate("DATA_ENTREGA"));
		emp.setUsuario( usuarioDAO.pesquisarById(rs.getLong("USUARIO_ID")) );
		emp.setExemplar( exemplarDAO.pesquisarById(rs.getLong("EXEMPLAR_ID")) );
		emp.setBibliotecario( bibliotecarioDAO.pesquisarById(rs.getLong("BIBLIOTECARIO_ID")) );
		
		return emp;
	}
}
