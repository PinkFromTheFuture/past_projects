package br.rj.senac.bibliosoft.model.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import br.rj.senac.bibliosoft.exception.DAOException;
import br.rj.senac.bibliosoft.model.Curso;
import br.rj.senac.bibliosoft.model.EntityModel;
import br.rj.senac.bibliosoft.model.conexao.MyConnection;
import br.rj.senac.bibliosoft.model.dao.ICursoDAO;

public class CursoJdbcDAO implements ICursoDAO {
	
	public void alterar(EntityModel em) throws DAOException {
		try {	
			if (em != null) {
				
				Curso curso = (Curso)em;
				
				String sql = "UPDATE CURSO SET NOME = ? WHERE CURSO_ID = ? ";
				
				Connection conn = MyConnection.getConnection();
				PreparedStatement ps = conn.prepareStatement(sql);
				
				ps.setString(1, curso.getNome());
				ps.setLong(2, curso.getId());
				
				ps.executeUpdate();
				
				ps.close();
			}
			
		} catch (Exception e) {
			throw new DAOException(e);
		}
	}

	public void excluir(EntityModel em) throws DAOException {
		try {	
			if (em != null) {
				
				Curso curso = (Curso)em;
				
				String sql = "DELETE FROM CURSO WHERE CURSO_ID = ? ";
				
				Connection conn = MyConnection.getConnection();
				PreparedStatement ps = conn.prepareStatement(sql);

				ps.setLong(1, curso.getId());
				
				ps.executeUpdate();
				
				ps.close();
			}
			
		} catch (Exception e) {
			throw new DAOException(e);
		}
	}

	public void inserir(EntityModel em) throws DAOException {
		try {	
			if (em != null) {
				
				Curso curso = (Curso)em;
				
				String sql = "INSERT INTO CURSO(NOME) VALUES (?) ";
				
				Connection conn = MyConnection.getConnection();
				PreparedStatement ps = conn.prepareStatement(sql);

				ps.setString(1, curso.getNome());
				
				ps.executeUpdate();
				
				ps.close();
			}
			
		} catch (Exception e) {
			throw new DAOException(e);
		}
	}

	public List<Curso> pesquisar(Curso curso) throws DAOException {
		try {
			
			List<Curso> col = new ArrayList<Curso>();
				
			String sql = "SELECT * FROM CURSO WHERE 1 = 1 ";
			
			if (curso != null && curso.getNome() != null) {
				sql += " AND NOME LIKE ? ";
			}
			
			Connection conn = MyConnection.getConnection();
			PreparedStatement ps = conn.prepareStatement(sql);

			if (curso != null && curso.getNome() != null) { 
				ps.setString(1, curso.getNome());	
			}
			
			ResultSet rs = ps.executeQuery();
			
			while (rs.next()) {
				Curso crs = new Curso();
				crs.setId(rs.getLong("CURSO_ID"));
				crs.setNome(rs.getString("NOME"));
				
				col.add(crs);
			}
			
			return col;
			
		} catch (Exception e) {
			throw new DAOException(e);
		}
	}

	public Curso pesquisarById(Long cursoId) throws DAOException {
		Curso curso = null;
		
		try {
			if (cursoId != null) {				

				String sql = "SELECT * FROM CURSO WHERE CURSO_ID = ? ";
				
				Connection conn = MyConnection.getConnection();
				PreparedStatement ps = conn.prepareStatement(sql); 
				ps.setLong(1, cursoId);
				
				ResultSet rs = ps.executeQuery();		
				
				if (rs.next()) {
					curso = new Curso();
					curso.setId(rs.getLong("CURSO_ID"));
					curso.setNome(rs.getString("NOME"));
				}
			}
			return curso;
			
		} catch (Exception e) {
			throw new DAOException(e);
		}
	}
}
