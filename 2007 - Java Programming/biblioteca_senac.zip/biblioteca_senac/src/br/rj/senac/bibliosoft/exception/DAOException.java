package br.rj.senac.bibliosoft.exception;


/**
 * 
 * Exce��o lan�ada pelos m�todos p�blicos da camada DAO. Todo m�todo de manipula��o 
 * de dados deve capturar as exce��es lan�adas pela API do mecanismo de persist�ncia
 * e lan�ar como DAOException.
 * 
 * Desta forma, definimos um contrato de comunica��o independente de implementa��o 
 * entre a camada DAO e a camada controller.
 * 
 * � lan�ada da camada Model (DAO) e capturada na camada Controller.
 *
 */
public class DAOException extends Exception {

	public DAOException(String msg) {
		super(msg);
	}
	
	public DAOException(Exception e) {
		super(e);
	}
	
	public DAOException(String msg, Exception e) {
		super(msg, e);
	}
}
