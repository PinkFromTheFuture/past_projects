package br.rj.senac.bibliosoft;

import java.util.List;

import br.rj.senac.bibliosoft.control.CadastroEditoraController;
import br.rj.senac.bibliosoft.exception.BusinessException;
import br.rj.senac.bibliosoft.exception.DatabaseException;
import br.rj.senac.bibliosoft.model.Editora;

public class CadastroEditoraMain {
	
	private static CadastroEditoraController cadastro = new CadastroEditoraController();
	
	public static void main(String[] args) {
		
		inserirEditora();
		excluirEditora();
		alterarEditora();
	}

	private static void inserirEditora() {
		
		Editora editora = new Editora();
		editora.setNome("Ci�ncia Moderna");
		
		try {
			
			cadastro.inserirEditora(editora);
			
		} catch (BusinessException e) {
			e.printStackTrace();
		} catch (DatabaseException e) {
			e.printStackTrace();
		}
	}
	
	private static void excluirEditora() {
		
		//Objeto que ser� usado como crit�rio na busca
		Editora ed = new Editora();
		ed.setNome("Ci�ncia Moderna");
		
		
		try {
			List<Editora> editoras = cadastro.pesquisarEditora(ed);
			
			for (Editora editora : editoras) {
				cadastro.excluirEditora(editora);	
			}

		} catch (BusinessException e) {
			e.printStackTrace();
		} catch (DatabaseException e) {
			e.printStackTrace();
		}
	}
	
	private static void alterarEditora() {
		
		//Objeto que ser� usado como crit�rio na busca
		Editora ed = new Editora();
		ed.setNome("Ci�ncia Moderna");
		
		
		try {
			List<Editora> editoras = cadastro.pesquisarEditora(ed);
			
			for (Editora editora : editoras) {
				editora.setNome("CIENCIA MODERNA");
				
				cadastro.alterarEditora(editora);	
			}

		} catch (BusinessException e) {
			e.printStackTrace();
		} catch (DatabaseException e) {
			e.printStackTrace();
		}
	}
}
