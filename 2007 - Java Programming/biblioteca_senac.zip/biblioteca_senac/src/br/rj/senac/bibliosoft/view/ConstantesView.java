package br.rj.senac.bibliosoft.view;

public class ConstantesView {
	public static final int FRAME_HEIGHT = 600;
	public static final int FRAME_WIDTH = 800;
	public static final int INTERNAL_FRAME_WIDTH = 795;
	public static final int INTERNAL_FRAME_HEIGHT = 550;
}
